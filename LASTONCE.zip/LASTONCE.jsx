import React, { useEffect, useState } from 'react';
import { InputLabel, FormControl, TextField, FormLabel, Radio, MenuItem, Select, RadioGroup, FormControlLabel, Checkbox } from '@mui/material';
import { Button } from 'react-bootstrap';
import axios from 'axios';
import './index.css';
import SubForm from './Sub';

export default function Index() {
  let initFormField;
  if (localStorage.getItem('FormField') == null) {
    initFormField = [];
  } else {
    initFormField = JSON.parse(localStorage.getItem('FormField'));
  }

  const [selectOption, setSelectedOption] = useState('Painter');

  const handleFormChange02 = (e) => {
    setSelectedOption(e.target.value);
  };

  const [formtype, setFormtype] = useState([
    { id: 1, label: 'Painter', value: 'Painter' },
    { id: 2, label: 'Plummer', value: 'Plummer' },
    { id: 3, label: 'Electrician', value: 'Electrician' },
  ]);

  const handleFormChange = (e) => {
    const type = e.target.value;
    setFormtype(type);
  };

  const [newField, setNewField] = useState({ type: '', label: '', option: [] });
  const [newOption, setNewOption] = useState({ label: '', value: '',option:[] });

  const handleFieldChange = (id, value) => {
    const updatedValue = [...formFields];
    const field = updatedValue.find((field) => field.id === id);
    field.value = value;
    setFormFields(updatedValue);
  };

  const handleNewFieldChange = (field, value) => {
    setNewField((prevField) => ({ ...prevField, [field]: value }));
  };

  const addOption = () => {
    if (newOption.label && newOption.value &&newOption.option) {
      setNewField((prevField) => ({ ...prevField, option: [...prevField.option, newOption] }));
      setNewOption({ label: '', value: '',option:[] });
    }
  };

  const AddField = (e) => {
    if (newField.type && newField.label) {
      const field = {
        id: formFields.length + 1,
        type: newField.type,
        label: newField.label,
        value: '',
        option: newField.option,
      };

      setFormFields((prevField) => [...prevField, field]);
      setNewField({ type: '', label: '', option: [] });
      localStorage.setItem('FormField', JSON.stringify(formFields));
    }
  };

  const [formFields, setFormFields] = useState(initFormField);

  const HandleSubmit = (e) => {
    e.preventDefault();
    console.log(formFields);
    console.log(selectOption);

    try {
      switch (selectOption) {
        case 'Painter':
          axios.post('http://localhost:8000/Painter-form', formFields).then((res) => {
            console.log(res);
          });
          break;
        case 'Plumber':
          axios.post('http://localhost:8000/Plumber-form', formFields).then((res) => {
            console.log(res);
          });
          break;
        case 'Electrician':
          axios.post('http://localhost:8000/Electrician-form', formFields).then((res) => {
            console.log(res);
          });
          break;
        default:
          break;
      }
    } catch (err) {
      console.log(err);
    }
  };

  const HandleDelete = (id) => {
    console.log('Delete One.........!', id);
    setFormFields(formFields.filter((e) => e.id !== id));
    localStorage.setItem('FormField', JSON.stringify(formFields));
  };

  const handleOptionDelete = (fieldId, optionValue) => {
    const updatedValue = [...formFields];
    const field = updatedValue.find((f) => f.id === fieldId);
    const index = field.option.findIndex((opt) => opt.value === optionValue);
    if (index > -1) {
      field.option.splice(index, 1);
    }
    setFormFields(updatedValue);
  };

  return (
    <>
      <div className="Container">
        <h1 style={{ fontFamily: ' Bungee Spice, cursive' }} className="f">
          Form Builder
        </h1>

        <FormControl>
          <h4>Select Type of Form That you likely to create :)</h4>
          {formtype.map((type) => (
            <label key={type.id}>
              <input
                type="radio"
                name="mi"
                value={type.value}
                onChange={handleFormChange02}
                checked={selectOption === type.value}
              />
              {type.label}
            </label>
          ))}
        </FormControl>

        {selectOption ? (
          <h4 className="mt-4 mb-4">I am Creating Form for: {selectOption}</h4>
        ) : null}

        <form className="form" action="">
          {formFields.map((field) => (
            <FormControl className="form-control mt-4" key={field.id} fullWidth>
              <FormLabel>{field.label}</FormLabel>
              {field.type === 'text' || field.type === 'email' ? (
                <>
                  <TextField value={field.value} type={field.type} name={field.name} onChange={(e) => handleFieldChange(field.id, e.target.value)} />
                  <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field.id)}>
                    Delete
                  </Button>
                  <hr />
                </>
              ) : field.type === 'radio' ? (
                <>
                  <RadioGroup value={field.value} onChange={(e) => handleFieldChange(field.id, e.target.value)}>
                    {field.option.map((option, i) => (
                      <FormControlLabel key={i} value={option.value} control={<Radio />} label={option.label} />
                    ))}
                  </RadioGroup>
                  <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field.id)}>
                    Delete
                  </Button>
                  <hr />
                </>
              ) : field.type === 'checkbox' ? (
                <div>
                  {field.option.map((option, index) => (
                    <FormControlLabel
                      key={index}
                      control={
                        <Checkbox
                          checked={field.value.includes(option.value)}
                          onChange={(e) => {
                            const isChecked = e.target.checked;
                            const updatedValue = [...field.value];
                            if (isChecked) {
                              updatedValue.push(option.value);
                            } else {
                              const index = updatedValue.indexOf(option.value);
                              if (index > -1) {
                                updatedValue.splice(index, 1);
                              }
                            }
                            handleFieldChange(field.id, updatedValue);
                          }}
                        />
                      }
                      label={option.label}
                    />
                  ))}
                  <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field.id)}>
                    Delete
                  </Button>
                  <hr />
                </div>
              ) : field.type === 'select' ? (
                <FormControl>
                  <InputLabel>{field.label}</InputLabel>
                  <Select value={field.value} onChange={(e) => handleFieldChange(field.id, e.target.value)}>
                    {field.option.map((option, index) => (
                      <MenuItem key={index} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </Select>
                  <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field.id)}>
                    Delete
                  </Button>
                  <hr />
                </FormControl>
              ) : null}
            </FormControl>
          ))}

          <div>
            <FormControl className="form-control mt-4" fullWidth>
              <InputLabel>New Field Type</InputLabel>
              <Select value={newField.type} onChange={(e) => handleNewFieldChange('type', e.target.value)}>
                <MenuItem value="text">Text</MenuItem>
                <MenuItem value="email">Email</MenuItem>
                <MenuItem value="radio">Radio</MenuItem>
                <MenuItem value="checkbox">Checkbox</MenuItem>
                <MenuItem value="select">Select</MenuItem>
              </Select>
            </FormControl>

            <TextField className="mt-4" label="New Field Label" value={newField.label} onChange={(e) => handleNewFieldChange('label', e.target.value)} />

            {newField.type === 'radio' || newField.type === 'checkbox' || newField.type === 'select' ? (
              <FormControl className="mt-4">
                <TextField
                  placeholder="New Option Label"
                  value={newOption.label}
                  onChange={(e) => setNewOption({ ...newOption, label: e.target.value })}
                />
                <TextField
                  placeholder="Radio Question"
                  value={newOption.value}
                  onChange={(e) => setNewOption({ ...newOption, value:[ e.target.value] })}
                />

                <TextField
                  placeholder="Radio option"
                  value={newOption.option}
                  onChange={(e) => setNewOption({ ...newOption, option:[ e.target.value] })}
                />
                {/* <SubForm /> */}


                <Button className="btn-secondary mt-4" onClick={addOption}>
                  Add Option
                </Button>
                <ul>
                  {newField.option.map((option, index) => {
                    return (
                      <li key={index}>
                        {option.label}
                        <Button className="btn-sm btn-danger" onClick={() => handleOptionDelete(newField.id, option.value)}>
                          Delete
                        </Button>
                      </li>
                    );
                  })}
                </ul>
              </FormControl>
            ) : null}
            <Button className="btn-success mx-1 mt-4" onClick={AddField}>
              Add Field
            </Button>
          </div>
          <Button type="submit" onClick={HandleSubmit} className="mb-4 mt-4">
            Submit
          </Button>
        </form>
      </div>
    </>
  );
}
