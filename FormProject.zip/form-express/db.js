const mongoose=require('mongoose');
const dbname='FormBuilder'
require('dotenv').config()
const DbHost=process.env.hostname;
const MongoUrl=`mongodb://${DbHost}:27017/${dbname}`

const ConnectMongo=async()=>{
  try{
    await mongoose.connect(MongoUrl)
    console.log('Db Connected Successfully.....')
  }
  catch(err){
    console.log('Error is',err)
  }
}

module.exports=ConnectMongo