const Form_field = require('../Model/Form_Field_schema')
const formSchema = require('../Model/Form')
const GetForm = async (req, res) => {
    // res.send('This is GetForm Api ')
    Form_field.findOne({})
        .then((formField) => {
            if (!formField) {
                res.json([])
            }
            else {
                res.json(formField.fields)
            }
        })
        .catch((err) => {
            console.log(err)
            res.json({ succuss: false, message: 'Internal Server Error' })
        })
}


const UpdateField = async (req, res) => {
    const { formField } = req.body;

    Form_field.findOne({})
        .then(async (existingfield) => {
            if (existingfield) {
                existingfield.fields = formField;

            }
            else {
                const newField = new Form_field({ fields: formField })
                return newField.save()
                // let savedField=await newField.save()
            }
        })
        .then(() => {
            res.json({ succuss: true, })
        })
        .catch((err) => {
            console.log(err)
        })
}

const mongoose = require('mongoose')

// const Form=mongoose.model('FormWithoutSchema',{}) 
const Insert = async (req, res) => {
    try {
        const { formField } = req.body;
        let user = new formSchema({ formField });
        let savedUser = await user.save()
        res.json({ succuss: true, savedUser })
    }
    catch (err) {
        console.log(err)
        res.json({ succuss: false, message: "Internal Server Error" })
    }


}

module.exports = { GetForm, UpdateField, Insert }