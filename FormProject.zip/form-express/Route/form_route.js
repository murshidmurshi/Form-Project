const express=require('express')
const route=express.Router()
const {GetForm,UpdateField,Insert}=require('../Controller/admin_controller')

route.get('/form-field',GetForm)
route.post('/update-form-field',UpdateField)
route.post('/insert',Insert)
// route.post('/insert',/* Insert */)

module.exports=route


