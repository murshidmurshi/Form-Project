// const express=require('express');
// const app=express()

// const ConnectMongo=require('./db')
// ConnectMongo()

// const cors=require('cors')
// app.use(cors())

// //define port and hostname
// require('dotenv').config();
// const hostname=process.env.hostname;
// const port=process.env.port;

// app.use(express.json())
// app.use('/api/form',require('./Route/form_route'))

// app.get('/get',(req,res)=>{
//     // console.log('This is / Page')
//     res.send('This is / Page')
// })

// app.listen(port,hostname,()=>{
//     console.log(`Successfully Connected to ${port} Port`)
// })


const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const port = 8000;
const cors = require('cors');
app.use(cors())
app.use(express.json());    

// Route for handling form submission
app.post('/Painter-form', async (req, res) => {
    try {
        const formData = req.body;
        // Connect to MongoDB
        const client = new MongoClient('mongodb://127.0.0.1:27017');
        await client.connect();


        // Access the database and collection
        const db = client.db('Form-Builder');
        const collection = db.collection('painter-form');

        // Save the form data to MongoDB
        await collection.insertOne({ formData });

        // Close the MongoDB connection
        await client.close();
        console.log('Connected to db ')
        res.json({ message: 'Painter Form submitted successfully' });
    } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).json({ message: 'Error submitting form' });
    }
});


app.post('/Tailor-form', async (req, res) => {
    try {
        const formData = req.body;
        // Connect to MongoDB
        const client = new MongoClient('mongodb://127.0.0.1:27017');
        await client.connect();


        // Access the database and collection
        const db = client.db('Form-Builder');
        const collection = db.collection('tailor-form');

        // Save the form data to MongoDB
        await collection.insertOne({ formData });

        // Close the MongoDB connection
        await client.close();
        console.log('Connected to db ')
        res.json({ message: 'Tailor Form submitted successfully' });
    } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).json({ message: 'Error submitting form' });
    }
});

app.post('/Plummer-form', async (req, res) => {
    try {
        const formData = req.body;
        // Connect to MongoDB
        const client = new MongoClient('mongodb://127.0.0.1:27017');
        await client.connect();


        // Access the database and collection
        const db = client.db('Form-Builder');
        const collection = db.collection('plummer-form');

        // Save the form data to MongoDB
        await collection.insertOne({ formData });

        // Close the MongoDB connection
        await client.close();
        console.log('Connected to db ')
        res.json({ message: 'Plummer Form submitted successfully' });
    } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).json({ message: 'Error submitting form' });
    }
});




app.get('/form-tailor', async (req, res) => {
    // res.send('This is Form Detail for User')
    // console.log(Collection.find())
    const client = new MongoClient('mongodb://127.0.0.1:27017');
    await client.connect();
    const db = client.db('Form-Builder');
    const collection = db.collection('tailor-form');
    const value = await collection.find().toArray()
    // console.log(value)
    // value.forEach((value, index) => {
    //     // console.log(value)
    //     return res.send((JSON.stringify(value, null, 2)));
    // })
    // console.log(value)
    
    res.send(value)
    await client.close()

})
app.get('/form-painter', async (req, res) => {
    // res.send('This is Form Detail for User')
    // console.log(Collection.find())
    const client = new MongoClient('mongodb://127.0.0.1:27017');
    await client.connect();
    const db = client.db('Form-Builder');
    const collection = db.collection('painter-form');
    const value = await collection.find().toArray()
    // console.log(value)
    // value.forEach((value, index) => {
    //     // console.log(value)
    //     return res.send((JSON.stringify(value, null, 2)));
    // })
    // console.log(value)
    
    res.send(value)
    await client.close()

})
app.get('/form-plummer', async (req, res) => {
    // res.send('This is Form Detail for User')
    // console.log(Collection.find())
    const client = new MongoClient('mongodb://127.0.0.1:27017');
    await client.connect();
    const db = client.db('Form-Builder');
    const collection = db.collection('plummer-form');
    const value = await collection.find().toArray()
    // console.log(value)
    // value.forEach((value, index) => {
    //     // console.log(value)
    //     return res.send((JSON.stringify(value, null, 2)));
    // })
    // console.log(value)
    
    res.send(value)
    await client.close()

})


//userFormSubmit

app.post('/FormFromPainter', async (req, res) => {
    try {
        const GainForm = req.body;

        // Connect to MongoDB
        const client = new MongoClient('mongodb://127.0.0.1:27017');
        await client.connect();


        // Access the database and collection
        const db = client.db('Form-Builder');
        const collection = db.collection('FormFromPainter');

        // Save the form data to MongoDB
        await collection.insertOne({ GainForm });

        // Close the MongoDB connection
        await client.close();
        console.log('Connected to db ')
        res.json({ message: 'Form submitted successfully' });
    } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).json({ message: 'Error submitting form' });
    }
});
app.post('/FormFromTailor', async (req, res) => {
    try {
        const GainForm = req.body;

        // Connect to MongoDB
        const client = new MongoClient('mongodb://127.0.0.1:27017');
        await client.connect();


        // Access the database and collection
        const db = client.db('Form-Builder');
        const collection = db.collection('FormFromTailor');

        // Save the form data to MongoDB
        await collection.insertOne({ GainForm });

        // Close the MongoDB connection
        await client.close();
        console.log('Connected to db ')
        res.json({ message: 'Form submitted successfully' });
    } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).json({ message: 'Error submitting form' });
    }
});
app.post('/FormFromPlummer', async (req, res) => {
    try {
        const GainForm = req.body;

        // Connect to MongoDB
        const client = new MongoClient('mongodb://127.0.0.1:27017');
        await client.connect();


        // Access the database and collection
        const db = client.db('Form-Builder');
        const collection = db.collection('FormFromPlummer');

        // Save the form data to MongoDB
        await collection.insertOne({ GainForm });

        // Close the MongoDB connection
        await client.close();
        console.log('Connected to db ')
        res.json({ message: 'Form submitted successfully' });
    } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).json({ message: 'Error submitting form' });
    }
});



app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
// const express = require('express');
// const mongoose = require('mongoose');
// const port = 8000;

// const app = express();
// app.use(express.json());


// // Connect to MongoDB
// mongoose.connect('mongodb://127.0.0.1/dynamic-form', { useNewUrlParser: true, useUnifiedTopology: true })
//     .then(() => console.log('Connected to MongoDB'))
//     .catch(error => console.error('Error connecting to MongoDB:', error));

// // Define the form schema
// const formSchema = new mongoose.Schema({
//     name: {
//         type: String,
//         required: true
//     },
//     email: {
//         type: String,
//         required: true
//     },
//     age: {
//         type: Number,
//         required: true
//     },
//     dynamicFields: [
//         {
//             type: {
//                 type: String,
//                 required: true
//             },
//             value: {
//                 type: String,
//                 required: true
//             }
//         }
//     ]
// });

// // Create the form model
// const Form = mongoose.model('Form', formSchema);

// app.get('/get',(req,res)=>{
//     res.send('This is / Page')
// })
// // Define a route to handle form submissions
// app.post('/submit-form', async (req, res) => {
//     try {
//         const formData = req.body; // Retrieve the form data directly from req.body

//         // Save the form data to the database
//         const formEntry = new Form(formData);
//         await formEntry.save();

//         res.send('Form submitted successfully',);
//     } catch (error) {
//         console.error('Error submitting form:', error);
//         res.status(500).send('An error occurred while submitting the form');
//     }
// });

// // Start the server
// app.listen(port, () => {
//     console.log(`Server running on port ${port}`);
// });












// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');
// const mongoose = require('mongoose');

// const app = express();
// app.use(cors());
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());

// // Connect to MongoDB
// mongoose.connect('mongodb://127.0.0.1/forms', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
//   .then(() => console.log('Connected to MongoDB'))
//   .catch((err) => console.error('Error connecting to MongoDB:', err));

// // Define the Form Schema
// const formSchema = new mongoose.Schema({}, { strict: false });

// const Form = mongoose.model('Form', formSchema);

// // API endpoint to submit the form data
// app.post('/submit-form', (req, res) => {
//   const formData = req.body;

//   const newForm = new Form(formData);

//   newForm.save()
//     .then(() => {
//       res.json({ success: true, message: 'Form submitted successfully' });
//     })
//     .catch((err) => {
//       res.status(500).json({ success: false, message: 'Failed to submit form', error: err });
//     });
// });

// // Start the server
// const port = 3000;
// app.listen(port, () => {
//   console.log(`Server started on port ${port}`);
// });
