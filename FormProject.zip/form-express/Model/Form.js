const mongoose = require('mongoose');

const formEntrySchema = new mongoose.Schema({
  label:{type:String,required:true},
  value:{type:String,required:true},
});
  // name: {
  //   type: String,
  //   required: true
  // },
  // email: {
  //   type: String,
  //   required: true
  // },
  // age: {
  //   type: Number,
  //   required: true
  // },
  // dynamicFields: [
  //   {
  //     type: {
  //       type: String,
  //       required: true
  //     },
  //     value: {
  //       type: String,
  //       required: true
  //     }
  //   }
  // ]
  
  const FormSchema=new mongoose.Schema({
    formfields:[formEntrySchema]
  })


const Form = mongoose.model('FEorm', FormSchema);

module.exports = Form;
