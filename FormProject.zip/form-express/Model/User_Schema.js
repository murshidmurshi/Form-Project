const mongoose=require('mongoose')

const {Schema}=mongoose

const user_Schema=new Schema(
    {
        name:mongoose.Schema.Types.Mixed,
        age:mongoose.Schema.Types.Mixed,
        // Add more fields as needed
    }
//    {
//    name:{
//     type:String,
//     required:true
//    },
//    age:{
//     type:Number,
//     required:true
//    },
//    gender:{
//     type:String,
//     required:true
//    },
//    date:{
//     type:Date,
//     default:Date.now()
//    }
// }
)

module.exports=mongoose.model('userform',user_Schema)