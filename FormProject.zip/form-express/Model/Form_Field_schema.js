const mongoose=require('mongoose')

const {Schema}=mongoose

const Form_field=new Schema({
   fields:[{
    name:String,
    label:String,
    type:String,
    options:[String],
    
   }]
})

module.exports=mongoose.model('FormField',Form_field)