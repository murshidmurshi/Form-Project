import React, { useEffect, useState } from 'react'
import { InputLabel, FormControl, TextField, FormLabel, Radio, MenuItem, Select, RadioGroup, FormControlLabel, Checkbox } from '@mui/material';
import { Button } from 'react-bootstrap';
import axios from 'axios';
import './index.css'
export default function Index() {
    let initFormField;
    if (localStorage.getItem('FormField') == null) {
        initFormField = []
    }
    else {
        initFormField = JSON.parse(localStorage.getItem('FormField'))
    }
    //make form for:

    const [selectOption, setSelectedOption] = useState('Painter')

    const handleFormChange02 = (e) => {
        setSelectedOption(e.target.value)
    }

    const [formtype, setFormtype] = useState([
        { id: 1, label: 'Painter', value: 'Painter', },
        { id: 2, label: 'Plummer', value: 'Plummer', },
        { id: 3, label: 'Electrition', value: 'Electrition', },
    ])

    const handleFormChange = (e) => {
        const type = e.target.value;
        setFormtype(type)
        console.log(type)
    }



    // console.log(build)
    const [newField, setNewField] = useState(
        { type: '', label: '', option: [] }
    )
    const [newOption, setNewOption] = useState('')
    // console.log(formFields)

    const handleFieldChange = (id, value) => {
        const UpdatedValue = [...formFields]
        const field = UpdatedValue.find(field => field.id === id)
        field.value = value
        setFormFields(UpdatedValue)
        // console.log(formFields)
    }
    const handleFormChange22 = (id, value) => {
        const UpdatedValue = [...formFields];
        const form = UpdatedValue.find(form => form.id === id)
        form.value = value
        setFormtype(UpdatedValue)

    }

    const handleNewFieldChange = (field, value) => {
        setNewField(prevField => ({ ...prevField, [field]: value }))
        // console.log(newField)
    }

    const addOption = () => {
        if (newOption) {
            setNewField(prevField => ({ ...prevField, option: [...prevField.option, newOption] }))
        }
    }

    const AddField = (e) => {

        if (newField.type && newField.label) {
            const Field = {
                id: formFields.length + 1,
                type: newField.type,
                label: newField.label,
                value: '',
                option: newField.option
            }

            setFormFields(prevField => [...prevField, Field])
            setNewField({ type: '', label: '', option: [] })

            localStorage.setItem('FormField', JSON.stringify(formFields))
        }

    }


    const [formFields, setFormFields] = useState(initFormField)

    // useEffect(() => {
    //     console.log('Effect In Select Options')
    //     if (localStorage.getItem('FormField')) {
    //         setFormFields([])
    //     }
    //     else {

    //         setFormFields([])
    //     }
    // }, [selectOption])

    const [clearform, setCleatrform] = useState('')
    const New = () => {
        if (formFields.length > 0) {
            setCleatrform(<Button onClick={ClearForm} style={{ backgroundColor: 'black', color: 'white', border: '3px solid Yellow' }}>Clear Form</Button>)
        }
        // else if(formFields.length==''){
        //     <Button>d</Button>
        // }
        else if (formFields.length == 0) {
            // console.log('d')
            setCleatrform('')
        }
    }
    useEffect(() => {
        localStorage.setItem('FormField', JSON.stringify(formFields))
        // const form = localStorage.getItem('FormField')
        console.log(formFields.length,)
        New()
    }, [formFields])

    // const DefaultForm = () => {
    //     console.log('Default Form')
    //     console.log(formtype)
    //     switch (formtype) {
    //         case 'Painter':
    //             return (
    //                 <>
    //                     <FormControl>
    //                         <FormLabel>Name:</FormLabel>
    //                         <TextField 
    //                             type='text'
    //                             value={''}
    //                             onChange={(e)=>handleFormChange22(1,e.target.value)}
    //                         />
    //                     </FormControl>
    //                 </>

    //             )
    //         case 'Tailor':
    //             return (
    //                 <>

    //                 </>
    //             )
    //     }
    // }


    const HandleSubmit = (e) => {
        e.preventDefault()
        console.log(formFields)
        console.log(selectOption)
        try {
            // const FormData = formFields.map((field) => ({
            //     label: field.label,
            //     value: field.value,
            // }
            // ))
            // axios.post('http://localhost:8000/api/form/insert', formFields)


            // const Empty=initFormField[(initFormField.length-1)].value=''
            // console.log(Empty,'ssssssssss')
            if (selectOption === 'Painter') {
                axios.post('http://localhost:8000/Painter-form', formFields)
                    .then((res) => {
                        console.log(res)
                    })
                    .catch((err) => {
                        console.log(err)
                    })
            }
            if (selectOption === 'Tailor') {
                axios.post('http://localhost:8000/Tailor-form', formFields)
                    .then((res) => {
                        console.log(res)
                    })
                    .catch((err) => {
                        console.log(err)
                    })
            }
            if (selectOption === 'Plummer') {
                axios.post('http://localhost:8000/Plummer-form', formFields)
                    .then((res) => {
                        console.log(res)
                    })
                    .catch((err) => {
                        console.log(err)
                    })
            }
        }
        catch (err) {
            console.log(err)
        }
    }

    const HandleDelete = (id) => {
        console.log('Delete One.........!', id)
        setFormFields(formFields.filter((e) => {
            return e !== id

        }))
        localStorage.setItem('FormField', JSON.stringify(formFields))

    }
    const ClearForm = () => {
        console.log('Clear Form')
        localStorage.removeItem('FormField')
        setFormFields([])
    }
    const handleOptiondelete = (id) => {
        console.log('Dlete one Option..........11')
        // console.log(setFormFields(formFields[3]))
        setFormFields(formFields.option((e) => {
            console.log(e)
        }))
    }

    // useEffect(() => {
    //     console.log('FFFFFFFFF??')
    // }, [localStorage.getItem('FormField')])

    return (
        <>
            <div className="Container">
                <h1 style={{ fontFamily: ' Bungee Spice, cursive' }} className='f'>Form Builder</h1>
                {/* <FormControl >
                    <InputLabel >Select Form Type</InputLabel>
                    <Select value={formtype} onChange={handleFormChange}>
                        <MenuItem value=''>Select Form Type</MenuItem>
                        <MenuItem value='Painter'>Painter</MenuItem>
                        <MenuItem value='Electrition'>Electrition</MenuItem>
                    </Select>
                </FormControl> */}

                <FormControl>
                    <h4>Select Type of Form That you likely to create :)</h4>
                    <label htmlFor="">
                        <input type="radio" name="mi" value={'Painter'} onChange={handleFormChange02} checked={selectOption === 'Painter'} />Painter
                    </label>
                    <label htmlFor="">
                        <input type="radio" name="mi" value={'Plummer'} onChange={handleFormChange02} checked={selectOption === 'Plummer'} />Plummer
                    </label>
                    <label htmlFor="">
                        <input type="radio" name="mi" value={'Tailor'} onChange={handleFormChange02} checked={selectOption === 'Tailor'} />Tailor
                    </label>
                    {selectOption ? <h4 className='mt-4 mb-4'>I am Creating Form for :{selectOption}</h4> : ''}

                </FormControl>

                <form className='form' action="">
                    <h1>{clearform}</h1>
                    {formFields.map(field =>
                    (
                        <FormControl className='form-control mt-4' key={field.id} fullWidth>
                            <FormLabel>{field.label}</FormLabel>
                            {field.type === 'text' || field.type === 'email' ? (
                                <>
                                    <TextField value={field.value} type={field.type} name={field.name} onChange={(e) => handleFieldChange(field.id, e.target.value)} />
                                    <Button style={{ width: '100px' }} className='inline btn-danger mt-4' onClick={() => HandleDelete(field)}>Delete</Button>
                                    <hr />
                                </>


                            ) : field.type == 'radio' ? (
                                <>
                                    <RadioGroup value={field.value} onChange={(e) => handleFieldChange(field.id, e.target.value)} >
                                        {field.option.map((option, i) => (
                                            <>
                                                <FormControlLabel
                                                    key={i}
                                                    value={option}
                                                    control={<Radio />}
                                                    label={option}

                                                />
                                                {/* <Button onClick={()=>handleOptiondelete(option)} className='btn-sm btn-danger'>Delete</Button> */}
                                            </>
                                        ))}

                                    </RadioGroup>
                                    <Button style={{ width: '100px' }} className='inline btn-danger mt-4' onClick={() => HandleDelete(field)}>Delete</Button>
                                    <hr />
                                </>
                            ) : field.type === 'checkbox' ? (
                                <div>
                                    {field.option.map((option, index) => (
                                        <FormControlLabel
                                            key={index}
                                            control={
                                                <Checkbox
                                                    checked={field.value.includes(option)}
                                                    onChange={(e) => {
                                                        const isChecked = e.target.checked;
                                                        const UpdatedValue = [...field.value]
                                                        if (isChecked) {
                                                            UpdatedValue.push(option)
                                                        }
                                                        else {
                                                            const index = UpdatedValue.indexOf(option)
                                                            if (index > -1) {
                                                                UpdatedValue.splice(index, 1)
                                                            }
                                                        }
                                                        handleFieldChange(field.id, UpdatedValue)
                                                    }}


                                                />
                                            }
                                            label={option}
                                        />
                                    ))}
                                    <Button style={{ width: '100px' }} className='inline btn-danger mt-4' onClick={() => HandleDelete(field)}>Delete</Button>
                                    <hr />
                                </div>
                            ) : field.type === 'select' ? (
                                <FormControl>
                                    <InputLabel>{field.label}</InputLabel>
                                    <Select
                                        value={field.value}
                                        onChange={(e) => handleFieldChange(field.id, e.target.value)}
                                    >
                                        {field.option.map((option, index) => (
                                            <MenuItem key={index} value={option}>{option}</MenuItem>
                                        ))}

                                    </Select>
                                    <Button style={{ width: '100px' }} className='inline btn-danger mt-4' onClick={() => HandleDelete(field)}>Delete</Button>
                                    <hr />
                                </FormControl>
                            )



                                : null}
                        </FormControl>
                    )
                    )}



                    <div>

                        <FormControl className='form-control mt-4' fullWidth>
                            <InputLabel>New Field Type</InputLabel>
                            <Select
                                value={newField.type}
                                onChange={(e) => handleNewFieldChange('type', e.target.value)}
                            >
                                <MenuItem value='text'>Text</MenuItem>
                                <MenuItem value='email'>Email</MenuItem>
                                <MenuItem value='radio'>Radio</MenuItem>
                                <MenuItem value='checkbox'>Checkbox</MenuItem>
                                <MenuItem value='select'>Select</MenuItem>
                            </Select>
                        </FormControl>

                        <TextField
                            className='mt-4'
                            label='New Field Label'
                            value={newField.label}
                            onChange={(e) => handleNewFieldChange('label', e.target.value)}
                        />

                        {newField.type == 'radio' || newField.type == 'checkbox' || newField.type == 'select' ? (
                            <FormControl className='mt-4'>

                                {/* <InputLabel ></InputLabel> */}
                                <TextField
                                    placeholder='New Option'
                                    value={newOption}
                                    onChange={(e) => setNewOption(e.target.value)}
                                />
                                <Button className='btn-secondary  mt-4' onClick={addOption}>Add Option </Button>
                                <ul >
                                    {newField.option.map((option, index) => {
                                        return (
                                            <>
                                                <li key={index}>{option}</li>

                                            </>
                                        )
                                    })}
                                </ul>

                            </FormControl>

                        ) : ''}
                        <Button className='btn-success mx-1 mt-4' onClick={AddField}>Add Field</Button>
                    </div>
                    <Button type='submit' onClick={HandleSubmit} className='mb-4 mt-4'>Submit</Button>
                </form>
            </div>
        </>
    )
}








{/* <Button style={{ width: "100px" }} className='btn-primary mt-4'>Submit</Button> */ }