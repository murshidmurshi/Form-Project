// // SubForm.jsx
// import React, { useState } from 'react';
// import FormControlLabel from '@mui/material/FormControlLabel';
// import Radio from '@mui/material/Radio';
// import RadioGroup from '@mui/material/RadioGroup';
// import Button from '@mui/material/Button';
// import TextField from '@mui/material/TextField';

// const SubForm = ({ formData, onChange, onAddSubform, removeSubForm, isParent }) => {
//   const [newOption, setNewOption] = useState('');

//   const containerStyle = {
//     border: '1px solid ',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightgreen' : 'lightblue',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleSubform = () => {
//     const newNames = { name: '', names: [], question: '', options: [] };
//     onChange('names', [...formData.names, newNames]);
//   };

//   const handleAddOption = () => {
//     if (newOption.trim() === '') {
//       return;
//     }

//     const newOptions = [...formData.options, newOption.trim()];
//     onChange('options', newOptions);
//     setNewOption('');
//   };

//   return (
//     <div style={containerStyle}>
//       <TextField
//         label="Question"
//         value={formData.question}
//         onChange={(e) => onChange('question', e.target.value)}
//       />

//       <RadioGroup
//         aria-label="name"
//         value={formData.name}
//         onChange={(e) => onChange('name', e.target.value)}
//       >
//         {formData.options.map((option) => (
//           <FormControlLabel key={option} value={option} control={<Radio />} label={option} />
//         ))}
//       </RadioGroup>

//       <input
//         type="text"
//         placeholder="Enter new option..."
//         value={newOption}
//         onChange={(e) => setNewOption(e.target.value)}
//       />
//       <Button variant="contained" color="primary" onClick={handleAddOption}>Add Option</Button>

//       {formData.names && formData.names.length > 0 && (
//         formData.names.map((name, index) => (
//           <SubForm
//             key={index}
//             formData={name}
//             onChange={(field, value) => {
//               const newNames = [...formData.names];
//               newNames[index][field] = value;
//               onChange('names', newNames);
//             }}
//             onAddSubform={onAddSubform}
//             removeSubForm={() => {
//               const newNames = [...formData.names];
//               newNames.splice(index, 1);
//               onChange('names', newNames);
//             }}
//             isParent={false} // Sub-forms should have a text field for the question as well
//           />
//         ))
//       )}

//       <Button color="primary" variant="contained" style={addButtonStyle} onClick={handleSubform}>Add Sub Form</Button>
//       <Button color="secondary" variant="contained" onClick={removeSubForm}>Remove Sub Form</Button>
//       <br />
//     </div>
//   );
// };

// export default SubForm;














// // SubForm.jsx
// import React, { useState } from 'react';
// import { TextField } from '@mui/material';

// export default function SubForm({ handleFieldChange }) {
//   const [subFormValue, setSubFormValue] = useState('');

//   const handleSubFormChange = (e) => {
//     setSubFormValue(e.target.value);
//     handleFieldChange('subForm', e.target.value);
//   };

//   return (
//     <div>
//       <h4>Sub-Form</h4>
//       <TextField label="Sub-Form Field" value={subFormValue} onChange={handleSubFormChange} />
//     </div>
//   );
// }




// import React from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import DeleteIcon from '@mui/icons-material/Delete';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent, handleAddSubForm }) => {
//   const containerStyle = {
//     border: '1px solid black',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleOptionChange = (index, value) => {
//     const newOptions = [...formData.options];
//     newOptions[index] = value;
//     onChange('options', newOptions);
//   };

//   const handleAddOption = () => {
//     const newOptions = [...formData.options, ''];
//     onChange('options', newOptions);
//   };

//   return (
//     <div style={containerStyle}>
//       <TextField
//         label="Name"
//         value={formData.name}
//         onChange={(e) => onChange('name', e.target.value)}
//         variant="outlined"
//         required
//         fullWidth
//         margin="normal"
//       />
//       {formData.options && formData.options.map((option, index) => (
//         <div key={index}>
//           <TextField
//             label={`Option ${index + 1}`}
//             value={option}
//             onChange={(e) => handleOptionChange(index, e.target.value)}
//             variant="outlined"
//             required
//             fullWidth
//             margin="normal"
//           />
//           {formData.names &&
//             formData.names[index] &&
//             formData.names[index].map((name, subIndex) => (
//               <SubForm
//                 key={subIndex}
//                 formData={name}
//                 onChange={(field, value) => {
//                   const newNames = [...formData.names];
//                   newNames[index][subIndex][field] = value;
//                   onChange('names', newNames);
//                 }}
//                 onAddSubForm={() => handleAddSubForm(formData.names[index])}
//                 onRemoveSubForm={() => {
//                   const newNames = [...formData.names];
//                   newNames[index].splice(subIndex, 1);
//                   onChange('names', newNames);
//                 }}
//                 isParent={false}
//                 handleAddSubForm={handleAddSubForm}
//               />
//             ))}
//           <Button variant="contained" color="primary" onClick={() => handleAddSubForm(formData.names[index])}>
//             Add Sub-Form
//           </Button>
//         </div>
//       ))}
//       <Button variant="contained" color="primary" onClick={handleAddOption}>
//         Add Option
//       </Button>
//       <Button variant="contained" color="secondary" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
//         Remove Sub-Form
//       </Button>8
//     </div>
//   );
// };

// export default SubForm;


// import React from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import DeleteIcon from '@mui/icons-material/Delete';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent, handleAddSubForm }) => {
//   const containerStyle = {
//     border: '1px solid black',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleOptionChange = (index, value) => {
//     const newOptions = [...formData.options];
//     newOptions[index] = value;
//     onChange('options', newOptions);
//   };

//   const handleAddOption = () => {
//     const newOptions = [...formData.options, ''];
//     onChange('options', newOptions);
//   };

//   return (
//     <div style={containerStyle}>
//       <TextField
//         label="Name"
//         value={formData.name}
//         onChange={(e) => onChange('name', e.target.value)}
//         variant="outlined"
//         required
//         fullWidth
//         margin="normal"
//       />
//       {formData.options &&
//         formData.options.map((option, index) => (
//           <div key={index}>
//             <TextField
//               label={`Option ${index + 1}`}
//               value={option}
//               onChange={(e) => handleOptionChange(index, e.target.value)}
//               variant="outlined"
//               required
//               fullWidth
//               margin="normal"
//             />
//             {formData.names &&
//               formData.names[index] &&
//               formData.names[index].map((name, subIndex) => (
//                 <SubForm
//                   key={subIndex}
//                   formData={name}
//                   onChange={(field, value) => {
//                     const newNames = [...formData.names];
//                     newNames[index][subIndex][field] = value;
//                     onChange('names', newNames);
//                   }}
//                   onAddSubForm={() => handleAddSubForm(formData.names[index])}
//                   onRemoveSubForm={() => {
//                     const newNames = [...formData.names];
//                     newNames[index].splice(subIndex, 1);
//                     onChange('names', newNames);
//                   }}
//                   isParent={false}
//                   handleAddSubForm={handleAddSubForm} // Pass the handleAddSubForm prop down
//                 />
//               ))}
//             <Button variant="contained" color="primary" onClick={() => handleAddSubForm(formData.names[index])}>
//               Add Sub-Form
//             </Button>
//           </div>
//         ))}
//       <Button variant="contained" color="primary" onClick={handleAddOption}>
//         Add Option
//       </Button>
//       <Button variant="contained" color="secondary" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
//         Remove Sub-Form
//       </Button>
//     </div>
//   );
// };

// export default SubForm;




// import React from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import DeleteIcon from '@mui/icons-material/Delete';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
//   const containerStyle = {
//     border: '1px solid black',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleOptionChange = (optionIndex, field, value) => {
//     const newOptions = [...formData.options];
//     newOptions[optionIndex][field] = value;
//     onChange('options', newOptions);
//   };

//   const handleAddOption = () => {
//     const newOptions = [...formData.options, { question: '', options: [''] }];
//     onChange('options', newOptions);
//   };

//   const handleAddSubOption = (optionIndex) => {
//     const newOptions = [...formData.options];
//     newOptions[optionIndex].options.push('');
//     onChange('options', newOptions);
//   };

//   const handleRemoveSubOption = (optionIndex, subOptionIndex) => {
//     const newOptions = [...formData.options];
//     newOptions[optionIndex].options.splice(subOptionIndex, 1);
//     onChange('options', newOptions);
//   };

//   return (
//     <div style={containerStyle}>
//       <TextField
//         label="Question"
//         value={formData.question}
//         onChange={(e) => onChange('question', e.target.value)}
//         variant="outlined"
//         required
//         fullWidth
//         margin="normal"
//       />
//       {formData.options &&
//         formData.options.map((option, optionIndex) => (
//           <div key={optionIndex}>
//             <TextField
//               label={`Option ${optionIndex + 1}`}
//               value={option}
//               onChange={(e) => handleOptionChange(optionIndex, 'options', e.target.value)}
//               variant="outlined"
//               required
//               fullWidth
//               margin="normal"
//             />
//             {formData.options &&
//               formData.options.map((subOption, subOptionIndex) => (
//                 <div key={subOptionIndex}>
//                   <TextField
//                     label={`Sub-Option ${subOptionIndex + 1}`}
//                     value={subOption}
//                     onChange={(e) => handleOptionChange(subOptionIndex, 'options', e.target.value)}
//                     variant="outlined"
//                     required
//                     fullWidth
//                     margin="normal"
//                   />
//                   <Button
//                     variant="contained"
//                     color="secondary"
//                     startIcon={<DeleteIcon />}
//                     onClick={() => handleRemoveSubOption(optionIndex, subOptionIndex)}
//                   >
//                     Remove Sub-Option
//                   </Button>
//                 </div>
//               ))}
//             <Button variant="contained" color="primary" onClick={() => handleAddSubOption(optionIndex)}>
//               Add Sub-Option
//             </Button>
//             {optionIndex !== 0 && (
//               <Button
//                 variant="contained"
//                 color="secondary"
//                 startIcon={<DeleteIcon />}
//                 onClick={() => onRemoveSubForm(optionIndex)}
//               >
//                 Remove Option
//               </Button>
//             )}
//           </div>
//         ))}
//       <Button variant="contained" color="primary" onClick={handleAddOption}>
//         Add Option
//       </Button>
//     </div>
//   );
// };

// export default SubForm;










import React from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';

const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
  const containerStyle = {
    border: '1px solid black',
    padding: '10px',
    margin: '10px',
    backgroundColor: isParent ? 'lightblue' : 'lightgreen',
  };

  const addButtonStyle = {
    backgroundColor: isParent ? 'lightblue' : 'lightgreen',
  };

  const handleOptionChange = (index, value) => {
    const newOptions = [...formData.options];
    newOptions[index] = value;
    onChange('options', newOptions);
  };

  const handleAddOption = () => {
    const newOptions = [...formData.options, {question:'',Option:[{}]}];
    onChange('options', newOptions);
  };

  const handleAddSubOption = (index) => {
    const newRadioOption = [...formData.mainOption[0].RadioOption];

    // Make sure 'yes' and 'option' properties exist and are in the correct format
    newRadioOption[index].yes = newRadioOption[index].yes || {};
    newRadioOption[index].yes.option = newRadioOption[index].yes.option || [];

    // If 'yes' is an empty object, convert it to an array with the original value
    if (!Array.isArray(newRadioOption[index].yes)) {
      newRadioOption[index].yes = [newRadioOption[index].yes];
    }

    // If 'option' is an empty object, convert it to an array
    if (!Array.isArray(newRadioOption[index].yes[0].option)) {
      newRadioOption[index].yes[0].option = [newRadioOption[index].yes[0].option];
    }

    // Push a new sub-option to the 'option' array
    newRadioOption[index].yes[0].option.push({ question: '', option: {} });

    // Update the state with the modified 'RadioOption' array
    onChange('mainOption', [
      {
        ...formData.mainOption[0],
        RadioOption: newRadioOption,
      },
    ]);
  };
  const handleSubOptionChange = (index, subIndex, field, value) => {
    const newRadioOption = [...formData.mainOption[0].RadioOption];
    newRadioOption[index].yes.option[subIndex][field] = value;
    onChange('mainOption', [
      {
        ...formData.mainOption[0],
        RadioOption: newRadioOption,
      },
    ]);
  };

  return (
    <div style={containerStyle}>
      <TextField
        label="Question"
        // value={formData.mainOption[0].Question}
        onChange={(e) => onChange('mainOption', [{ ...formData.mainOption[0], Question: e.target.value }])}
        variant="outlined"
        required
        fullWidth
        margin="normal"
      />
      {/* {formData.mainOption[0].RadioOption &&
        formData.mainOption[0].RadioOption.map((radioOption, index) => (
          <div key={index}>
            <TextField
              label={`Option ${index + 1}`}
              value={radioOption.name}
              onChange={(e) => handleOptionChange(index, e.target.value)}
              variant="outlined"
              required
              fullWidth
              margin="normal"
            />
            {radioOption.yes &&
              radioOption.yes.option &&
              radioOption.yes.option.map((subOption, subIndex) => (
                <div key={subIndex}>
                  <TextField
                    label={`Sub-Option ${subIndex + 1}`}
                    value={subOption.question}
                    onChange={(e) => handleSubOptionChange(index, subIndex, 'question', e.target.value)}
                    variant="outlined"
                    required
                    fullWidth
                    margin="normal"
                  />
                  {/* If you want to have an input for the sub-option's option, you can add it here 
                </div>
              ))}
            <Button variant="contained" color="primary" onClick={() => handleAddSubOption(index)}>
              Add Sub-Option
            </Button>
          </div>
        ))} */}
      <Button variant="contained" color="primary" onClick={handleAddOption}>
        Add Option
      </Button>
      <Button variant="contained" color="secondary" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
        Remove Sub-Form
      </Button>
    </div>
  );
};

export default SubForm;











/////////////////
////////////////

// import React, { useState } from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import DeleteIcon from '@mui/icons-material/Delete';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
//   const containerStyle = {
//     border: '1px solid black',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleAddSubForm = () => {
//     const newFormData = { question: '',option:'', names: [] };
//     onChange('names', [...formData.names, newFormData]);
//   };

//   return (
//     <div style={containerStyle}>
//       <TextField
//         label="Question"
//         value={formData.name}
//         onChange={(e) => onChange('Question', e.target.value)}
//         variant="outlined"
//         required
//         fullWidth
//         margin="normal"
//       />

//       {formData.names.length<1&&(

      
//       <TextField
//         label="Option"
//         // value={formData.name}
//         // onChange={(e) => onChange('', e.target.value)}
//         variant="outlined"
//         required
//         fullWidth
//         margin="normal"
//       />
//       )
// }
//       {formData.names &&
//         formData.names.map((name, index) => (
//           <SubForm
//             key={index}
//             formData={name}
//             onChange={(field, value) => {
//               const newNames = [...formData.names];
//               newNames[index][field] = value;
//               onChange('names', newNames);
//             }}
//             onAddSubForm={onAddSubForm}
//             onRemoveSubForm={() => {
//               const newNames = [...formData.names];
//               newNames.splice(index, 1);
//               onChange('names', newNames);
//             }}
//           />
//         ))}

//       <Button variant="contained" color="primary" style={addButtonStyle} onClick={handleAddSubForm}>
//         Add Sub-Form
//       </Button>
//       <Button variant="contained" color="secondary" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
//         Remove Sub-Form
//       </Button>
//     </div>
//   );
// };

// const ContactForm = () => {
//   const [forms, setForms] = useState([{ Question: '', names: [] }]);

//   const handleChange = (index, field, value) => {
//     setForms(prevForms => {
//       const newForms = [...prevForms];
//       newForms[index][field] = value;
//       return newForms;
//     });
//   };

//   const addSubForm = (formData) => {
//     if (!formData.names) {
//       formData.names = [];
//     }
//     formData.names.push({Option:'', Question: '', names: [] });
//     setForms([...forms]);
//   };

//   const removeParentForm = (index) => {
//     const newForms = [...forms];
//     newForms.splice(index, 1);
//     setForms(newForms);
//   };

//   const handleSubmit = () => {
//     console.log('Form Data:', forms);
//     // You can perform additional actions with the form data here.
//   };

//   return (
//     <div>
//       <h1>Contact Information</h1>
//       {forms.map((form, index) => (
//         <div key={index}>
//           <SubForm
//             formData={form}
//             onChange={(field, value) => handleChange(index, field, value)}
//             onAddSubForm={() => addSubForm(form)}
//             onRemoveSubForm={() => removeParentForm(index)}
//             isParent={index === 0}
//           />
//           {index !== 0 && (
//             <Button
//               variant="contained"
//               color="secondary"
//               startIcon={<DeleteIcon />}
//               onClick={() => removeParentForm(index)}
//             >
//               Remove Parent Form0
//             </Button>
//           )}
//         </div>
//       ))}
//       <Button variant="contained" color="primary" onClick={() => setForms([...forms, { name: '', names: [] }])}>
//         Add Parent Form
//       </Button>
//       <Button variant="contained" color="primary" onClick={handleSubmit}>
//         Submit
//       </Button>
//     </div>
//   );
// };

// export default ContactForm;
///////////////////
// //////////
////