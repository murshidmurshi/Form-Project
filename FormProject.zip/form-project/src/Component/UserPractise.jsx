import { InputLabel, FormControl, TextField, FormLabel, Radio, MenuItem, Button, Select, RadioGroup, FormControlLabel, Checkbox, Textarea } from '@mui/material';
import axios from 'axios'
import React, { useState } from 'react'
import { useEffect } from 'react'
import { } from 'react-bootstrap';
import './user.css'

// import TextareaAutosize from '@mui/base/TextareaAutosize';



export default function User() {
    const [selectOption, setSelectedOption] = useState('')
    const [selectedMainselect, setSelectedMainSELECTION] = useState([])
    const [selectionStack, setSelectionStack] = useState([])

    const [responses, setResponses] = useState([])



    const [selectT, setSelectT] = useState(false)

    const [radioset, setRadioset] = useState('')

    const SELECTMAP = selectedMainselect.state;
    console.log(selectedMainselect.state, 89898998)
    const handleFormChange02 = (e) => {
        setSelectedOption(e.target.value)
    }
    console.log(selectOption)
    console.log(selectedMainselect, 787877878787878789899)
    const [formdata, setFormData] = useState([])
    // const [formFields,setFormFields]=useState([])
    let mi;
    console.log(formdata)
    useEffect(() => {
        // console.log('Hellooo........!!')
        if (selectOption === 'Painter') {
            axios.get('http://localhost:8000/form-painter')
                .then((res) => {
                    console.log(res)

                    console.log((res.data).length - 1, 11111)

                    //Last Form That you created
                    const LastForm = ((res.data).length - 1)
                    setFormData(res.data[LastForm].formData)
                    // setFormData(res.data[0].formData)

                })
                .catch((err) => {
                    console.log(err)
                })
        }
        if (selectOption === 'Tailor') {
            axios.get('http://localhost:8000/form-tailor')
                .then((res) => {
                    console.log((res.data).length - 1, 11111)

                    //Last Form That you created
                    const LastForm = ((res.data).length - 1)
                    setFormData(res.data[LastForm].formData)
                    // setFormData(res.data[0].formData)
                })
                .catch((err) => {
                    console.log(err)
                })
        }
        if (selectOption === 'Plummer') {
            axios.get('http://localhost:8000/form-plummer')
                .then((res) => {
                    console.log((res.data).length - 1, 11111)

                    //Last Form That you created
                    const LastForm = ((res.data).length - 1)
                    setFormData(res.data[LastForm].formData)
                    // setFormData(res.data[0].formData)
                })
                .catch((err) => {
                    console.log(err)
                })
        }

    }, [selectOption])

    const SimpleSubmit = () => {
        console.log(SELECTMAP, 'Simple Form')
    }

    // const MainSELECT;
    const handleFieldChange = (id, value) => {
        const UpdatedValue = [...formdata]
        const field = UpdatedValue.find(field => field.id === id)
        field.value = value
        setSelectedMainSELECTION(value)
        setSelectT(true)

        setFormData(UpdatedValue)
        console.log(SELECTMAP, 99999999999999)
        // console.log(formdata)
    }


    const handleRadio = (e) => {
        // console.log(e.target.value, 89889898989)
        setRadioset(e.target.value)

    }
    const handleSelection = (selectOption, level) => {


        const UpdatedSelect = [...selectionStack.slice(0, selectionStack.findIndex(item => item.Question === level) + 1), selectOption]


        console.log((selectionStack.findIndex(item => item.Question === level) + 1), 'FindIndex')
        console.log(selectionStack.Question, 33333333333333333333333333)
        // const UpdatedSelect = [...selectionStack, selectOption]
        setSelectionStack(UpdatedSelect)
        // console.log(UpdatedSelect, 111111111111)


        setResponses(prevresponse => ({
            ...prevresponse,
            [level]: selectOption.Option
        })
        )
    }

    const handleBack = () => {
        if (selectionStack.length > 1) {

            const UpdateSelection = selectionStack.splice(0, selectionStack.length - 1)
            setSelectionStack(UpdateSelection)
        }
    }
    const handleTextChange = (event, Question) => {
        const newText = event.target.value
        setResponses(prevresponse => ({
            ...prevresponse,
            [Question]: newText
        }))

    }


    const RadioBack = () => {
        if (selectionStack.length > 0) {
            const UpdateSelection = selectionStack.splice(0, selectionStack.length - 1)
            setSelectionStack(UpdateSelection)
        }
        console.log('hiihih')
    }




    const HandleSubmit = (e) => {
        e.preventDefault()
        console.log('Main You Selected', selectedMainselect)

        // console.log('Submit')
        console.log(formdata)
        // console.log(SELECTMAP, 'slefldhjkhfdjkhjskfhjds')
        console.log(responses, 'RESPONSES')
        // const FormData = formdata.map((field) => ({
        //     label: field.label,
        //     value: field.value,

        // }
        // ))

        const Answer = responses
        // console.log(Answer[0].includes(undefined),'ANSWER5655665')






        if (selectOption === 'Painter') {
            axios.post('http://localhost:8000/FormFromPainter', Answer)
                .then((res) => {
                    console.log(res)
                    console.log('Submitted Painter Form SuccussFully')
                })
                .catch((err) => {
                    console.log(err)
                })
        }
        if (selectOption === 'Tailor') {
            axios.post('http://localhost:8000/FormFromTailor', Answer)
                .then((res) => {
                    console.log(res)
                    console.log('Submitted  Tailor Form  SuccussFully')
                })
                .catch((err) => {
                    console.log(err)
                })
        }
        if (selectOption === 'Plummer') {
            axios.post('http://localhost:8000/FormFromPlummer', Answer)
                .then((res) => {
                    console.log(res)
                    console.log('Submitted  Plummer Form  SuccussFully')
                })
                .catch((err) => {
                    console.log(err)
                })
        }

        console.log(formdata)
    }
    console.log(SELECTMAP, 'SelecteMAP')
    console.log(SELECTMAP, 'SelecteMAP', 565656565565)




    return (
        <>
            <hr />
            <h1>User Side</h1>
            <hr />

            <div className='SubmitForm'>
                <FormControl >
                    <h4>Which Form Do You Want to Submit :)</h4>
                    <label>
                        <input type="radio" name="mi" value={'Painter'} onChange={handleFormChange02} checked={selectOption === 'Painter'} />Painter Form
                    </label>
                    <label>
                        <input type="radio" name="mi" value={'Plummer'} onChange={handleFormChange02} checked={selectOption === 'Plummer'} />Plummer Form
                    </label>
                    <label>
                        <input type="radio" name="mi" value={'Tailor'} onChange={handleFormChange02} checked={selectOption === 'Tailor'} />Tailor Form
                    </label>
                    {/* {selectOption ? <h1>Form for {selectOption}</h1> : <h1>Form For </h1>} */}

                </FormControl>
            </div>
            <div>
                <h1 className='mt-4 formhead text-center'>Form for {selectOption}</h1>
            </div>
            <div className='formdiv'>
                {formdata.map((field, index) =>
                (
                    <FormControl style={{ padding: '20px' }} key={index} className='form-control mt-4' fullWidth>
                        <FormLabel>{field.label}</FormLabel>
                        {field.type === 'text' || field.type === 'email' ? (

                            <TextField value={field.value} type={field.type} name={field.name} onChange={(e) => handleFieldChange(field.id, e.target.value)} />


                        ) : field.type == 'radio' ? (
                            <RadioGroup value={field.value} onChange={(e) => handleFieldChange(field.id, e.target.value)} >
                                {field.option.map((option, index) => (
                                    <FormControlLabel
                                        key={index}
                                        value={option}
                                        control={<Radio />}
                                        label={option}
                                    />
                                ))}

                            </RadioGroup>
                        ) : field.type === 'checkbox' ? (
                            <div>
                                {field.option.map((option, index) => (
                                    <FormControlLabel
                                        key={index}
                                        control={
                                            <Checkbox
                                                checked={field.value.includes(option)}
                                                onChange={(e) => {
                                                    const isChecked = e.target.checked;
                                                    const UpdatedValue = [...field.value]
                                                    if (isChecked) {
                                                        UpdatedValue.push(option)
                                                    }
                                                    else {
                                                        const index = UpdatedValue.indexOf(option)
                                                        if (index > -1) {
                                                            UpdatedValue.splice(index, 1)
                                                        }
                                                    }
                                                    handleFieldChange(field.id, UpdatedValue)
                                                }}


                                            />
                                        }
                                        label={option}
                                    />
                                ))}
                            </div>
                        ) : field.type === 'select' ? (
                            <FormControl>
                                <InputLabel>{field.label}</InputLabel>
                                <Select
                                    value={field.value}
                                    onChange={(e) => handleFieldChange(field.id, e.target.value)}
                                >
                                    {field.option.map((option, index) => (
                                        <MenuItem key={index} value={option}>{option.newOption}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        )



                            : null}
                    </FormControl>
                )

                )}



                <div>
                    <br />



                    <h2>HELLO World</h2>
                    <br />
                    {SELECTMAP && (

                        <FormControl>
                            {Object.keys(SELECTMAP).map((mainOption) => (
                                <FormControlLabel
                                    value={mainOption}
                                    control={<Radio


                                        checked={selectionStack.length > 0 && selectionStack[selectionStack.length - 1].Option === mainOption}
                                        onChange={() => {
                                            handleSelection(SELECTMAP[mainOption])
                                            console.log(SELECTMAP[mainOption], 89889898)

                                        }}
                                    />}

                                    label={selectedMainselect.newOption + ' Form'}
                                />

                            ))}
                        </FormControl>

                    )}

                </div>
                <div style={{ backgroundColor: 'yellowGreen' }}>
                    <hr />
                    <hr />
                    <hr />

                </div>
                <div>
                    {console.log(selectionStack,8055555)}
                    {selectionStack.map((level, index) => (
                        <div key={index}>
                            <br />
                            <h3>{level.Question}</h3>
                            <RadioGroup
                                aria-label={level.Question}
                                name={level.Question}
                                value={level.selectedOption} // You need to manage the selected value for each level
                            >
                                {level.names.map((nameOption, nameIndex) => (
                                    <FormControlLabel
                                        key={nameIndex}
                                        control={<Radio
                                            onChange={() => {
                                                handleSelection(nameOption, level.Question)

                                            }}

                                        />}
                                        value={nameOption.Option}
                                        label={nameOption.Option}



                                    />




                                ))}
                            </RadioGroup>
                            {level.TEXT && (
                                <div>
                                    <FormLabel>{level.TEXT}</FormLabel> <br />
                                    <TextField
                                        onChange={(e) => handleTextChange(e, level.TEXT)}
                                        placeholder='write anything You want!!!!'


                                    />
                                </div>

                            )}
                            <div style={{ backgroundColor: 'black' }}>
                                <hr />
                            </div>

                            {/* <Button onClick={handleBack} variant='contained' color='secondary'>
                                Back
                            </Button>
                            <Button onClick={handleBack} className='mx-4' variant='contained' color='success'>
                                Continue
                            </Button> */}

                            <br />
                        </div>



                    ))}
                </div>

                <br />
                <Button type='submit' onClick={HandleSubmit} className='mt-4 mb-4 '>Submit</Button>


                <Button type='submit' onClick={SimpleSubmit} className='mt-4 mb-4 '>SimpleSubmit</Button>
            </div>






        </>
    )
}
