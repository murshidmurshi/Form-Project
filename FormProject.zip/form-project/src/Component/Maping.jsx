
import React, { useState } from 'react';
import {
    RadioGroup,
    FormControlLabel,
    Radio,
    Button,
    FormControl,
    FormLabel,
    TextField,
} from '@mui/material';
import { Add } from '@mui/icons-material';



const optionsData = [
    {
        Question: 'Painteraaaaaaaaaaaaa?',
        names: [
            {
                Option: 'Bresh', Question: 'Breshaaaaaaaaaaaa?',
                names: [
                    {
                        Option: 'BigBresh', Question: 'BigBreshaaaaaaaaaaa?',
                        names: [
                            { Option: 'Yes', TEXT: '4545455', names: [] },
                            { Option: 'No', Question: 'Noaaaaaaaaaaaaahaaaaaaaaaaa?', names: [] },
                            { Option: 'Maybe', Question: 'MayBeaaaaaaaaaaa?', names: [] },
                            { Option: 'Other', Question: 'Otheraaaaaaaaaaa?', names: [] },
                        ]
                    },
                    { Option: 'SmallBresh', Question: 'SmallBreshaaaaaaaaaaa?', names: [] },
                    { Option: 'mineBresh', Question: 'MineBreshaaaaaaaaaa?', names: [] },
                ]
            },
            { Option: 'Color', Question: 'Coloraaaaaaaaa?', names: [] },
            { Option: 'Plat', Question: 'Plataaaaaaaaaaa?', names: [] },
            { Option: 'REDCOLORs', Question: 'REDCOLORssaaaaaaaaaaaa?', names: [] },
        ]
    },
    {
        Question: 'TailoraaaaaaaaaaaaaaaForm?', Option: 'AAAAAA',
        names: [
            { Option: 'Button', Question: 'Butttonaaaaaaaaaaaaa?', names: [] },
            { Option: 'Shirt', Question: 'Shirtaaaaaaaaa?', names: [] },
            { Option: 'Pant', Question: 'Pantaaaaaaaaaaa?', names: [] },
            { Option: 'Dress', Question: 'Dressaaaaaaaaaaaa?', names: [] },
        ]
    }
    // ... other options
];



const Submit = () => {
    console.log('Submit')
}


export default function User() {
    const [selectionStack, setSelectionStack] = useState([]);
    const [responses, setResponses] = useState({});
    const [maketrue, setMaketrue] = useState(false);

    const handleSelection = (selectedOption, level) => {
        const updatedStack = [...selectionStack.slice(0, selectionStack.findIndex(item => item.Question === level) + 1), selectedOption];
        console.log((selectionStack.findIndex(item => item.Question === level) + 1), 'FindIndex')
        // console.log((selectionStack.findIndex(item => item.Question === level) + 1), selectionStack.Question === level + 1, 898988999)
        setSelectionStack(updatedStack);

        // // Clear responses for subsequent levels
        // const updatedResponses = { ...responses };
        // const subsequentLevels = optionsData.slice(optionsData.findIndex(item => item.Question === level) + 1);
        // console.log(optionsData.findIndex(item => item.Question === level) + 1, 'Subsequense Level')
        // subsequentLevels.forEach(subsequentLevel => {
        //     updatedResponses[subsequentLevel.Question] = undefined;
        // });
        // setResponses(updatedResponses);
        // console.log('updatedResponses', updatedResponses)
    };
    console.log('selectedStack,,,,,,', selectionStack)


    const handleContinue = () => {
        setMaketrue(true);
    };

    const handleSubmit = () => {
        console.log('Submit');
        console.log(responses);
        console.log(optionsData);
    };



    // console.log(newQuestion, 'NEwQuestion................11')
    // console.log(newOption, 'NewOption...............11')
    return (
        <div>
            <FormControl>
                {Object.keys(optionsData).map((mainOption) => (
                    <FormControlLabel
                        key={mainOption} // Add a key prop for React's optimization
                        value={mainOption}
                        control={

                        <Radio
                            checked={selectionStack.length > 0 && selectionStack[selectionStack.length - 1].Option === mainOption}
                            onChange={() => {
                                handleSelection(optionsData[mainOption], '')
                                {console.log(optionsData[mainOption]);}

                            }}
                        />
                    }
                        label={mainOption + ' Form'}
                    />
                ))}
                <Button color='success' onClick={handleContinue} variant='contained'>Continue</Button>
            </FormControl>
            <hr />
            <hr />
            {maketrue && (

                selectionStack.map((level, index) => (
                    <>
                        {/* {console.log(selectedOption)} */}
                        <div key={index}>
                            <h3>{level.Question}</h3>
                            <RadioGroup
                                aria-label={level.Question}
                                name={level.Question}
                                value={level.selectedOption}

                            // You need to manage the selected value for each level
                            >
                                {level.names.map((nameOption, nameIndex) => (

                                    <FormControlLabel
                                        key={nameOption.Option} // Add a key prop for React's optimization
                                        control={<Radio />}
                                        value={nameOption.Option}
                                        label={nameOption.Option}
                                        // onClick={handleRemoveUpdate}

                                        onChange={() => {
                                            handleSelection(nameOption, level.Question)
                                            console.log(level.Question,nameOption,  'eeeeeeeeeeeeeeeeeeeee')
                                        }}
                                    />
                                ))}
                                
                            </RadioGroup>
                            {level.TEXT && (
                                <div>
                                    <FormLabel>{level.TEXT}</FormLabel>
                                    <br />
                                    <TextField
                                        name={level.TEXT} // Set the name attribute
                                        placeholder='Enter Something'
                                        value={responses[level.TEXT] || ''} // Bind TextField value to responses
                                    // onChange={(event) => handleTextChange(event, level.TEXT)}
                                    />
                                </div>
                            )}

                            <div style={{ backgroundColor: 'black' }}>
                                <hr />
                            </div>
                            {/* <Button onClick={handleBack} variant='contained' color='secondary'>
                                Back
                            </Button> */}
                            <Button onClick={handleContinue} variant='contained' color='success'>
                                Continue
                            </Button>
                        </div>
                    </>
                ))


            )}
            {/* {setMaketrue(false)} */}


            <Button onClick={handleSubmit}>Submit</Button>
        </div>
    );
}