
import React, { useEffect, useState } from 'react';
import {
    InputLabel,
    FormControl,
    TextField,
    FormLabel,
    Radio,
    MenuItem,
    Select,
    RadioGroup,
    FormControlLabel,
    Checkbox,
    FormGroup,
} from '@mui/material';
import { Button } from 'react-bootstrap';
import axios from 'axios';

import './index.css';

import { aaa, bbb } from './Chat'

import Chat from '../Component/Chat'

export default function Index() {


    let ChatsAAA = aaa;
    let initFormField;
    if (localStorage.getItem('FormField') == null) {
        initFormField = [];
    } else {
        initFormField = JSON.parse(localStorage.getItem('FormField'));
    }

    const [selectOption, setSelectedOption] = useState('Painter');

    const handleFormChange02 = (e) => {
        setSelectedOption(e.target.value);
    };

    const [formtype, setFormtype] = useState([
        { id: 1, label: 'Painter', value: 'Painter' },
        { id: 2, label: 'Plummer', value: 'Plummer' },
        { id: 3, label: 'Electrition', value: 'Electrition' },
    ]);

    const handleFormChange = (e) => {
        const type = e.target.value;
        setFormtype(type);
        console.log(type);
    };

    const [newField, setNewField] = useState({
        type: '',
        label: '',
        option: [],

    });

    const [newOption, setNewOption] = useState('');
    const [clear, setClear] = useState(false)

    const handleFieldChange = (id, value) => {
        const UpdatedValue = [...formFields];
        const field = UpdatedValue.find((field) => field.id === id);
        field.value = value;
        setFormFields(UpdatedValue);
    };

    const handleFormChange22 = (id, value) => {
        const UpdatedValue = [...formFields];
        const form = UpdatedValue.find((form) => form.id === id);
        form.value = value;
        setFormtype(UpdatedValue);
    };

    const handleNewFieldChange = (field, value) => {
        setNewField((prevField) => ({ ...prevField, [field]: value }));
    };

    const addOption = () => {

        if (newOption) {

            if (newField.type == 'select') {
                setNewField((prevField) => ({ ...prevField, option: [...prevField.option, { newOption, state: aaa }] }));
            } else {
                setNewField((prevField) => ({ ...prevField, option: [...prevField.option, newOption] }));
            }

            bbb([{ Option: '', names: [], Question: '' }])
        }
    };

    const AddField = (e) => {
        if (newField.type && newField.label) {
            const Field = {
                id: formFields.length + 1,
                type: newField.type,
                label: newField.label,
                value: '',
                option: newField.option,
                // state: aaa,
            };

            setFormFields((prevField) => [...prevField, Field]);
            setNewField({ type: '', label: '', option: [] });
            localStorage.setItem('FormField', JSON.stringify(formFields));
        }
    };

    const [formFields, setFormFields] = useState(initFormField);

    const [clearform, setCleatrform] = useState('');

    const New = () => {
        if (formFields.length > 0) {
            setCleatrform(
                <Button onClick={ClearForm} style={{ backgroundColor: 'black', color: 'white', border: '3px solid Yellow' }}>
                    Clear Form
                </Button>
            );
        } else if (formFields.length === 0) {
            setCleatrform('');

        }
    };

    useEffect(() => {
        localStorage.setItem('FormField', JSON.stringify(formFields));
        New();
    }, [formFields]);

    const HandleSubmit = (e) => {
        e.preventDefault();
        console.log(formFields);
        console.log('AnotherComponent Value', aaa, 4444444444444)

        
        console.log(selectOption);
        try {
            if (selectOption === 'Painter') {
                axios.post('http://localhost:8000/Painter-form', formFields).then((res) => {
                    console.log(res);
                });
            }
            if (selectOption === 'Tailor') {
                axios.post('http://localhost:8000/Tailor-form', formFields).then((res) => {
                    console.log(res);
                });
            }
            if (selectOption === 'Plummer') {
                axios.post('http://localhost:8000/Plummer-form', formFields).then((res) => {
                    console.log(res);
                });
            }
        } catch (err) {
            console.log(err);
        }
    };

    const HandleDelete = (id) => {
        console.log('Delete One.........!', id);
        setFormFields(formFields.filter((e) => e !== id));
        localStorage.setItem('FormField', JSON.stringify(formFields));
        // const name='NAMe'
    };

    const ClearForm = () => {
        console.log('Clear Form');
        localStorage.removeItem('FormField');
        setFormFields([]);
    };

    const handleOptiondelete = (id) => {
        console.log('Delete one Option..........11');
        setFormFields(
            formFields.option((e) => {
                console.log(e);
            })
        );
    };

    const [newtext, setNewText] = useState(false);

    const ClickChange = (id) => {
        console.log('clickChange');
    };

    const [showTRYForm, setShowTRYForm] = useState(false);

    const handleCheckboxChange = (fieldId, isChecked) => {
        const UpdatedValue = [...formFields];
        const checkboxField = UpdatedValue.find((field) => field.id === fieldId);
        checkboxField.checked = isChecked;
        setFormFields(UpdatedValue);
        setShowTRYForm(isChecked);
    };




    return (
        <>
            <hr />

            <h1>Admin Side</h1>
            <hr />
            <div className="Container">
                <h1 style={{ fontFamily: ' Bungee Spice, cursive' }} className="f">
                    Form Builder
                </h1>
                <FormControl>
                    <h4>Select Type of Form That you likely to create :)</h4>
                    <label htmlFor="">
                        <input
                            type="radio"
                            name="mi"
                            value={'Painter'}
                            onChange={handleFormChange02}
                            checked={selectOption === 'Painter'}
                        />
                        Painter
                    </label>
                    <label htmlFor="">
                        <input
                            type="radio"
                            name="mi"
                            value={'Plummer'}
                            onChange={handleFormChange02}
                            checked={selectOption === 'Plummer'}
                        />
                        Plummer
                    </label>
                    <label htmlFor="">
                        <input
                            type="radio"
                            name="mi"
                            value={'Tailor'}
                            onChange={handleFormChange02}
                            checked={selectOption === 'Tailor'}
                        />
                        Tailor
                    </label>
                    {selectOption ? <h4 className="mt-4 mb-4">I am Creating Form for :{selectOption}</h4> : ''}
                </FormControl>
                <form className="form" >
                    <h1>{clearform}</h1>
                    {formFields.map((field) => (
                        <FormControl className="form-control mt-4" key={field.id} fullWidth>
                            <FormLabel>{field.label}</FormLabel>
                            {field.type === 'text' || field.type === 'email' ? (
                                <>
                                    <TextField value={field.value} type={field.type} name={field.name} onChange={(e) => handleFieldChange(field.id, e.target.value)} />
                                    <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field)}>
                                        Delete
                                    </Button>
                                    <hr />
                                </>
                            ) : field.type === 'radio' ? (
                                <>
                                    <RadioGroup value={field.value} onChange={(e) => handleFieldChange(field.id, e.target.value)}>
                                        {field.option.map((option, i) => (
                                            <FormControlLabel key={i} value={option} control={<Radio />} label={option} />
                                        ))}
                                    </RadioGroup>
                                    <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field)}>
                                        Delete
                                    </Button>
                                    <hr />
                                </>
                            ) : field.type === 'checkbox' ? (
                                <FormControl>
                                    <FormGroup>
                                        {field.option.map((option, index) => (
                                            <>
                                                <FormControlLabel
                                                    key={index}
                                                    control={
                                                        <Checkbox
                                                            checked={field.checked}
                                                            onChange={(e) => {
                                                                const isChecked = e.target.checked;
                                                                handleCheckboxChange(field.id, isChecked);
                                                            }}
                                                        />
                                                    }
                                                    label={option}
                                                />
                                                {field.checked ? (
                                                    <div style={{ paddingLeft: '20px' }}>
                                                        {/* <TRYForm onFormSubmit={(data) => handleFieldChange(field.id, [...field.options, data])} /> */}
                                                    </div>
                                                ) : (
                                                    ''
                                                )}
                                            </>
                                        ))}
                                        <br />
                                        <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field)}>
                                            Delete
                                        </Button>
                                        <hr />
                                    </FormGroup>
                                </FormControl>
                            ) : field.type === 'select' ? (
                                <FormControl>
                                    <InputLabel>{field.label}</InputLabel>
                                    <Select value={field.value} onChange={(e) => handleFieldChange(field.id, e.target.value)}>
                                        {field.option.map((option, index) => (
                                            <MenuItem key={index} value={option}>
                                                {option.newOption}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                    <br />
                                    <Button style={{ width: '100px' }} className="inline btn-danger mt-4" onClick={() => HandleDelete(field)}>
                                        Delete
                                    </Button>
                                    <hr />
                                </FormControl>
                            ) : null}
                        </FormControl>
                    ))}
                    <div>
                        <FormControl className="form-control mt-4" fullWidth>
                            <InputLabel>New Field Type</InputLabel>
                            <Select value={newField.type} onChange={(e) => handleNewFieldChange('type', e.target.value)}>
                                <MenuItem value="text">Text</MenuItem>
                                <MenuItem value="email">Email</MenuItem>
                                <MenuItem value="radio">Radio</MenuItem>
                                <MenuItem value="checkbox">Checkbox</MenuItem>
                                <MenuItem value="select">Select</MenuItem>
                            </Select>
                        </FormControl>

                        <TextField
                            className="mt-4"
                            label="New Field Label"
                            value={newField.label}
                            onChange={(e) => handleNewFieldChange('label', e.target.value)}
                        />

                        {newField.type == 'radio' || newField.type == 'checkbox' ? (
                            <FormControl className='mt-4'>

                                {/* <InputLabel ></InputLabel> */}
                                <TextField
                                    placeholder='New Option'
                                    value={newOption}
                                    onChange={(e) => setNewOption(e.target.value)}
                                />
                                <Button className="btn-secondary mt-4" onClick={addOption}>
                                    Add Option
                                </Button>
                                <ul >
                                    {newField.option.map((option, index) => {
                                        return (
                                            <>
                                                <li key={index}>{option}?</li>

                                            </>
                                        )
                                    })}
                                </ul>

                            </FormControl>

                        ) : newField.type === 'select' ? (
                            <FormControl className="mt-4">
                                <TextField
                                    placeholder="New Option"
                                    value={newOption}
                                    onChange={(e) => setNewOption(e.target.value)}
                                />

                                <Chat />


                                <Button className="btn-secondary mt-4" onClick={addOption}>
                                    Add Option
                                </Button>

                                <ul>
                                    {newField.option.map((option, index) => {
                                        return <li key={index}>{option.newOption}</li>;
                                    })}
                                </ul>
                            </FormControl>
                        ) : (
                            ''
                        )}
                        <br />

                        <br />


                        <Button className="btn-success mb-4 mx-1 mt-4" onClick={AddField}>
                            Add Field
                        </Button>
                    </div>
                    <Button onClick={HandleSubmit} className="mb-4 mt-4">
                        Submit
                    </Button>
                </form>
            </div>
        </>
    );
}
