

// import React, { useState } from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import AddCircleIcon from '@mui/icons-material/AddCircle';
// import DeleteIcon from '@mui/icons-material/Delete';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
//   let [addtext, setAddtext] = useState(true);

//   const containerStyle = {
//     border: '2px solid black',
//     borderRadius: '20px',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleAddSubForm = () => {
//     const newFormData = { Option: '', Question: '', names: [] };
//     onChange('names', [...formData.names, newFormData]);
//     setAddtext(false);
//   };

//   const ADDTEXT = () => {
//     setAddtext(true);
//   };

//   return (
//     <div style={containerStyle}>
//       {!isParent && (
//         <TextField
//           label="Option"
//           required
//           onChange={(e) => onChange('Option', e.target.value)}
//           variant="outlined"
//           fullWidth
//           margin="normal"
//         />
//       )}

//       <TextField
//         label="Question"
//         required
//         value={formData.name}
//         onChange={(e) => onChange('Question', e.target.value)}
//         variant="outlined"
//         fullWidth
//         margin="normal"
//       />

//       {addtext ? (
//         !isParent && (
//           <TextField
//             label="LABEL"
//             required
//             value={formData.name}
//             onChange={(e) => onChange('TEXT', e.target.value)}
//             variant="outlined"
//             fullWidth
//             margin="normal"
//           />
//         )
//       ) : (
//         ''
//       )}

//       {formData.names &&
//         formData.names.map((name, index) => (
//           <SubForm
//             key={index}
//             formData={name}
//             onChange={(field, value) => {
//               const newNames = [...formData.names];
//               newNames[index][field] = value;
//               onChange('names', newNames);
//             }}
//             onAddSubForm={onAddSubForm}
//             onRemoveSubForm={() => {
//               const newNames = [...formData.names];
//               newNames.splice(index, 1);
//               onChange('names', newNames);
//             }}
//           />
//         ))}

//       <Button
//         variant="contained"
//         color="primary"
//         startIcon={<AddCircleIcon />}
//         onClick={handleAddSubForm}
//       >
//         Add Sub-Form
//       </Button>

//       <Button
//         className="mx-4"
//         variant="contained"
//         color="error"
//         startIcon={<DeleteIcon />}
//         onClick={onRemoveSubForm}
//       >
//         Remove Sub-Form
//       </Button>
//     </div>
//   );
// };

// const ContactForm = () => {
//   const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);

//   const handleChange = (index, field, value) => {
//     setForms((prevForms) => {
//       const newForms = [...prevForms];
//       newForms[index][field] = value;
//       return newForms;
//     });
//   };

//   const addSubForm = (formData) => {
//     if (!formData.names) {
//       formData.names = [];
//     }
//     formData.names.push({ Option: '', Question: '', names: [] });
//     setForms([...forms]);
//   };

//   const removeParentForm = (index) => {
//     const newForms = [...forms];
//     newForms.splice(index, 1);
//     setForms(newForms);
//   };

//   const handleSubmit = () => {
//     console.log('Form Data:', forms);
//     console.log('length:', forms.length);
//     // You can perform additional actions with the form data here.
//   };

//   return (
//     <div>
//       <br />
//       <h1>Add work and sub work</h1>
//       <div>

//         <SubForm
//           formData={forms[0]}
//           onChange={(field, value) => handleChange(0, field, value)}
//           onAddSubForm={() => addSubForm(forms[0])}
//           onRemoveSubForm={() => removeParentForm(0)}
//           isParent={true}
//         />
//         <Button
//           variant="contained"
//           color="error"
//           startIcon={<DeleteIcon />}
//           onClick={() => removeParentForm(0)}
//         >
//           Remove Parent Form0
//         </Button>
//       </div>

//       {forms.length === 0 ? (
//         <Button
//           variant="contained"
//           color="primary"
//           onClick={() =>
//             setForms([...forms, { Option: '', Question: '', names: [] }])
//           }
//         >
//           Add Parent Form
//         </Button>
//       ) : (
//         ''
//       )}
//       <Button variant="contained" color="primary" onClick={handleSubmit}>
//         Submit
//       </Button>
//     </div>
//   );
// };

// export default ContactForm;




import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import DeleteIcon from '@mui/icons-material/Delete';

const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
  let [addtext, setAddtext] = useState(true);

  const containerStyle = {
    border: '2px solid black',
    borderRadius: '20px',
    padding: '10px',
    margin: '10px',
    backgroundColor: isParent ? 'lightblue' : 'lightgreen',
  };

  const addButtonStyle = {
    backgroundColor: isParent ? 'lightblue' : 'lightgreen',
  };

  const handleAddSubForm = () => {
    const newFormData = { Option: '', Question: '', names: [] };
    onChange('names', [...formData.names, newFormData]);
    console.log('Index', newFormData)
    setAddtext(false);
  };

  const ADDTEXT = () => {
    setAddtext(true);
  };

  return (
    <div style={containerStyle}>
      {!isParent && (
        <TextField
          label="Option"
          required
          onChange={(e) => onChange('Option', e.target.value)}
          variant="outlined"
          fullWidth
          margin="normal"
        />
      )}

      <TextField
        label="Question"
        required
        value={formData.name}
        onChange={(e) => onChange('Question', e.target.value)}
        variant="outlined"
        fullWidth
        margin="normal"
      />

      {addtext ? (
        !isParent && (
          <TextField
            label="LABEL"
            required
            value={formData.name}
            onChange={(e) => onChange('TEXT', e.target.value)}
            variant="outlined"
            fullWidth
            margin="normal"
          />
        )
      ) : (
        ''
      )}

      {formData.names &&
        formData.names.map((name, index) => (
          <SubForm
            key={index}
            formData={name}

            onChange={(field, value) => {
              const newNames = [...formData.names];
              newNames[index][field] = value;
              onChange('names', newNames);
            }}

            // onAddSubForm={onAddSubForm}
            onRemoveSubForm={() => {
              const newNames = [...formData.names];
              newNames.splice(index, 1);
              onChange('names', newNames);
            }}
          />
        ))}

      <Button
        variant="contained"
        color="primary"
        startIcon={<AddCircleIcon />}
        onClick={handleAddSubForm}
      >
        Add Sub-Form
      </Button>

      <Button
        className="mx-4"
        variant="contained"
        color="error"
        startIcon={<DeleteIcon />}
        onClick={onRemoveSubForm}
      >
        Remove Sub-Form
      </Button>
    </div>
  );
};

const ContactForm = () => {
  const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);

  const handleChange = (index, field, value) => {
    setForms((prevForms) => {
      const newForms = [...prevForms];
      newForms[index][field] = value;
      return newForms;
    });
  };

  const addSubForm = (formData) => {
    if (!formData.names) {
      formData.names = [];
    }

    formData.names.push({ Option: '', Question: '', names: [] });
    setForms([...forms]);
  };

  const removeParentForm = (index) => {
    const newForms = [...forms];
    newForms.splice(index, 1);
    setForms(newForms);
  };

  const handleSubmit = () => {
    console.log('Form Data:', forms);
    console.log('length:', forms.length);
    // You can perform additional actions with the form data here.
  };

  return (
    <div>
      <br />
      <h1>Add work and sub work</h1>
      <div>

        <SubForm
          formData={forms[0]}
          onChange={(field, value) => handleChange(0, field, value)}
          onAddSubForm={() => addSubForm(forms[0])}
          onRemoveSubForm={() => removeParentForm(0)}
          isParent={true}
        />
        <Button
          variant="contained"
          color="error"
          startIcon={<DeleteIcon />}
          onClick={() => removeParentForm(0)}
        >
          Remove Parent Form0
        </Button>
      </div>

      {forms.length === 0 ? (
        <Button
          variant="contained"
          color="primary"
          onClick={() =>
            setForms([...forms, { Option: '', Question: '', names: [] }])
          }
        >
          Add Parent Form
        </Button>
      ) : (
        ''
      )}
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Submit
      </Button>
    </div>
  );
};

export default ContactForm;



// Correct Method ------------------------------------------------------
// Correct Method ------------------------------------------------------

// import React, { useState } from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import AddCircleIcon from '@mui/icons-material/AddCircle';
// import DeleteIcon from '@mui/icons-material/Delete';
// import Accordion from '@mui/material/Accordion';
// import AccordionSummary from '@mui/material/AccordionSummary';
// import AccordionDetails from '@mui/material/AccordionDetails';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
//   let [addtext, setAddtext] = useState(true);

//   const containerStyle = {
//     border: '2px solid black',
//     borderRadius: '20px',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleAddSubForm = () => {
//     const newFormData = { Option: '', Question: '', names: [] };
//     onChange('names', [...formData.names, newFormData]);
//     setAddtext(false);
//   };

//   const ADDTEXT = () => {
//     setAddtext(true);
//   };

//   return (
//     <div style={containerStyle}>
//       {!isParent && (
//         <TextField
//           label="Option"
//           required
//           onChange={(e) => onChange('Option', e.target.value)}
//           variant="outlined"
//           fullWidth
//           margin="normal"
//         />
//       )}

//       <TextField
//         label="Question"
//         required
//         value={formData.Question}
//         onChange={(e) => onChange('Question', e.target.value)}
//         variant="outlined"
//         fullWidth
//         margin="normal"
//       />

//       {addtext ? (
//         !isParent && (
//           <TextField
//             label="LABEL"
//             required
//             value={formData.TEXT}
//             onChange={(e) => onChange('TEXT', e.target.value)}
//             variant="outlined"
//             fullWidth
//             margin="normal"
//           />
//         )
//       ) : (
//         ''
//       )}
// <br />
//       {formData.names &&
//         formData.names.map((name, index) => (
//           <Accordion key={index}>
//             <AccordionSummary
//               expandIcon={<ExpandMoreIcon />}
//               aria-controls={`panel${index}-content`}
//               id={`panel${index}-header`}
//             >
//               {/* Render any additional information for each "names" entry here */}
//             </AccordionSummary>
//             <AccordionDetails>

//               <SubForm
//                 formData={name}
//                 onChange={(field, value) => {
//                   const newNames = [...formData.names];
//                   newNames[index][field] = value;
//                   onChange('names', newNames);
//                 }}
//                 onAddSubForm={onAddSubForm}
//                 onRemoveSubForm={() => {
//                   const newNames = [...formData.names];
//                   newNames.splice(index, 1);
//                   onChange('names', newNames);
//                 }}
//               />
//               <br />
//             </AccordionDetails>
//           </Accordion>
//         ))}

//       <Button
//         variant="contained"
//         color="primary"
//         startIcon={<AddCircleIcon />}
//         onClick={handleAddSubForm}
//       >
//         Add Sub-Form
//       </Button>

//       <Button
//         className="mx-4"
//         variant="contained"
//         color="error"
//         startIcon={<DeleteIcon />}
//         onClick={onRemoveSubForm}
//       >
//         Remove Sub-Form
//       </Button>
//     </div>
//   );
// };

// const ContactForm = () => {
//   const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);

//   const handleChange = (index, field, value) => {
//     setForms((prevForms) => {
//       const newForms = [...prevForms];
//       newForms[index][field] = value;
//       return newForms;
//     });
//   };

//   const addSubForm = (formData) => {
//     if (!formData.names) {
//       formData.names = [];
//     }
//     formData.names.push({ Option: '', Question: '', names: [] });
//     setForms([...forms]);
//   };

//   const removeParentForm = (index) => {
//     const newForms = [...forms];
//     newForms.splice(index, 1);
//     setForms(newForms);
//   };

//   const handleSubmit = () => {
//     console.log('Form Data:', forms);
//     console.log('length:', forms.length);
//     // You can perform additional actions with the form data here.
//   };

//   return (
//     <div>
//       <br />
//       <h1>Add work and sub work</h1>
//       <div>
//         <SubForm
//           formData={forms[0]}
//           onChange={(field, value) => handleChange(0, field, value)}
//           onAddSubForm={() => addSubForm(forms[0])}
//           onRemoveSubForm={() => removeParentForm(0)}
//           isParent={true}
//         />
//         <Button
//           variant="contained"
//           color="error"
//           startIcon={<DeleteIcon />}
//           onClick={() => removeParentForm(0)}
//         >
//           Remove Parent Form0
//         </Button>
//       </div>

//       {forms.length === 0 ? (
//         <Button
//           variant="contained"
//           color="primary"
//           onClick={() =>
//             setForms([...forms, { Option: '', Question: '', names: [] }])
//           }
//         >
//           Add Parent Form
//         </Button>
//       ) : (
//         ''
//       )}
//       <Button variant="contained" color="primary" onClick={handleSubmit}>
//         Submit
//       </Button>
//     </div>
//   );
// };

// export default ContactForm;




// import React, { useState } from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import AddCircleIcon from '@mui/icons-material/AddCircle';
// import DeleteIcon from '@mui/icons-material/Delete';
// import Accordion from '@mui/material/Accordion';
// import AccordionSummary from '@mui/material/AccordionSummary';
// import AccordionDetails from '@mui/material/AccordionDetails';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
//   let [addtext, setAddtext] = useState(true);

//   const containerStyle = {
//     border: '2px solid black',
//     borderRadius: '20px',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleAddSubForm = () => {
//     const newFormData = { Option: '', Question: '', names: [] };
//     onChange('names', [...formData.names, newFormData]);
//     setAddtext(false);
//   };

//   const ADDTEXT = () => {
//     setAddtext(true);
//   };

//   return (
//     <div style={containerStyle}>
//       {!isParent && (
//         <TextField
//           label="Option"
//           required
//           onChange={(e) => onChange('Option', e.target.value)}
//           variant="outlined"
//           fullWidth
//           margin="normal"
//         />
//       )}

//       <TextField
//         label="Question"
//         required
//         value={formData.Question}
//         onChange={(e) => onChange('Question', e.target.value)}
//         variant="outlined"
//         fullWidth
//         margin="normal"
//       />

//       {addtext ? (
//         !isParent && (
//           <TextField
//             label="LABEL"
//             required
//             value={formData.TEXT}
//             onChange={(e) => onChange('TEXT', e.target.value)}
//             variant="outlined"
//             fullWidth
//             margin="normal"
//           />
//         )
//       ) : (
//         ''
//       )}

//       {formData.names &&
//         formData.names.map((name, index) => (
//           <Accordion key={index} style={{ marginBottom: '16px', backgroundColor: 'lightgray' }}>
//             <AccordionSummary
//               expandIcon={<ExpandMoreIcon />}
//               aria-controls={`panel${index}-content`}
//               id={`panel${index}-header`}
//               style={{ backgroundColor: 'lightblue', fontWeight: 'bold' }}
//             >
//               {/* Render any additional information for each "names" entry here */}
//             </AccordionSummary>
//             <AccordionDetails style={{ padding: '8px', backgroundColor: 'white' }}>
//               <SubForm
//                 formData={name}
//                 onChange={(field, value) => {
//                   const newNames = [...formData.names];
//                   newNames[index][field] = value;
//                   onChange('names', newNames);
//                 }}
//                 onAddSubForm={onAddSubForm}
//                 onRemoveSubForm={() => {
//                   const newNames = [...formData.names];
//                   newNames.splice(index, 1);
//                   onChange('names', newNames);
//                 }}
//               />
//             </AccordionDetails>
//           </Accordion>
//         ))}

//       <Button
//         variant="contained"
//         color="primary"
//         startIcon={<AddCircleIcon />}
//         onClick={handleAddSubForm}
//       >
//         Add Sub-Form
//       </Button>

//       <Button
//         className="mx-4"
//         variant="contained"
//         color="error"
//         startIcon={<DeleteIcon />}
//         onClick={onRemoveSubForm}
//       >
//         Remove Sub-Form
//       </Button>
//     </div>
//   );
// };

// const ContactForm = () => {
//   const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);

//   const handleChange = (index, field, value) => {
//     setForms((prevForms) => {
//       const newForms = [...prevForms];
//       newForms[index][field] = value;
//       return newForms;
//     });
//   };

//   const addSubForm = (formData) => {
//     if (!formData.names) {
//       formData.names = [];
//     }
//     formData.names.push({ Option: '', Question: '', names: [] });
//     setForms([...forms]);
//   };

//   const removeParentForm = (index) => {
//     const newForms = [...forms];
//     newForms.splice(index, 1);
//     setForms(newForms);
//   };

//   const handleSubmit = () => {
//     console.log('Form Data:', forms);
//     console.log('length:', forms.length);
//     // You can perform additional actions with the form data here.
//   };

//   return (
//     <div>
//       <br />
//       <h1>Add work and sub work</h1>
//       <div>
//         <SubForm
//           formData={forms[0]}
//           onChange={(field, value) => handleChange(0, field, value)}
//           onAddSubForm={() => addSubForm(forms[0])}
//           onRemoveSubForm={() => removeParentForm(0)}
//           isParent={true}
//         />
//         <Button
//           variant="contained"
//           color="error"
//           startIcon={<DeleteIcon />}
//           onClick={() => removeParentForm(0)}
//         >
//           Remove Parent Form0
//         </Button>
//       </div>

//       {forms.length === 0 ? (
//         <Button
//           variant="contained"
//           color="primary"
//           onClick={() =>
//             setForms([...forms, { Option: '', Question: '', names: [] }])
//           }
//         >
//           Add Parent Form
//         </Button>
//       ) : (
//         ''
//       )}
//       <Button variant="contained" color="primary" onClick={handleSubmit}>
//         Submit
//       </Button>
//     </div>
//   );
// };

// export default ContactForm;


// import React, { useState, Fragment } from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import AddCircleIcon from '@mui/icons-material/AddCircle';
// import DeleteIcon from '@mui/icons-material/Delete';
// import Accordion from '@mui/material/Accordion';
// import AccordionSummary from '@mui/material/AccordionSummary';
// import AccordionDetails from '@mui/material/AccordionDetails';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
// import Dialog from '@mui/material/Dialog';
// import DialogActions from '@mui/material/DialogActions';
// import DialogContent from '@mui/material/DialogContent';
// import DialogContentText from '@mui/material/DialogContentText';
// import DialogTitle from '@mui/material/DialogTitle';

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
//   let [addtext, setAddtext] = useState(true);
//   const [openDialog, setOpenDialog] = useState(false);

//   const containerStyle = {
//     border: '2px solid black',
//     borderRadius: '20px',
//     padding: '10px',
//     margin: '10px',
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const addButtonStyle = {
//     backgroundColor: isParent ? 'lightblue' : 'lightgreen',
//   };

//   const handleAddSubForm = () => {
//     const newFormData = { Option: '', Question: '', names: [] };
//     onChange('names', [...formData.names, newFormData]);
//     setAddtext(false);
//   };

//   const ADDTEXT = () => {
//     setAddtext(true);
//   };

//   const handleDialogOpen = () => {
//     setOpenDialog(true);
//   };

//   const handleDialogClose = () => {
//     setOpenDialog(false);
//   };

//   return (
//     <div style={containerStyle}>
//       {!isParent && (
//         <TextField
//           label="Option"
//           required
//           onChange={(e) => onChange('Option', e.target.value)}
//           variant="outlined"
//           fullWidth
//           margin="normal"
//         />
//       )}

//       <TextField
//         label="Question"
//         required
//         value={formData.Question}
//         onChange={(e) => onChange('Question', e.target.value)}
//         variant="outlined"
//         fullWidth
//         margin="normal"
//       />

//       {addtext ? (
//         !isParent && (
//           <TextField
//             label="Label"
//             required
//             value={formData.Label}
//             onChange={(e) => onChange('Label', e.target.value)}
//             variant="outlined"
//             fullWidth
//             margin="normal"
//           />
//         )
//       ) : (
//         ''
//       )}

//       {formData.names &&
//         formData.names.map((name, index) => (
//           <Accordion
//             key={index}
//             style={{
//               marginBottom: '16px',
//               // backgroundColor: name.expanded ? 'red' : 'black', // Change the background color here
//             }}
//           >
//             <AccordionSummary
//               expandIcon={<ExpandMoreIcon />}
//               aria-controls={`panel${index}-content`}
//               id={`panel${index}-header`}
//               style={{ backgroundColor: 'black', fontWeight: 'bold' }}
//             >
//               {/* Render any additional information for each "names" entry here */}
//               {name.Option && (
//                 <Fragment>
//                   <span>Option: {name.Option}</span>
//                   <Button variant="outlined" onClick={() => handleDialogOpen(name)}>
//                     Edit
//                   </Button>
//                 </Fragment>
//               )}
//             </AccordionSummary>
//             <AccordionDetails style={{ padding: '8px', backgroundColor: 'white' }}>
//               <SubForm
//                 formData={name}
//                 onChange={(field, value) => {
//                   const newNames = [...formData.names];
//                   newNames[index][field] = value;
//                   onChange('names', newNames);
//                 }}
//                 onAddSubForm={onAddSubForm}
//                 onRemoveSubForm={() => {
//                   const newNames = [...formData.names];
//                   newNames.splice(index, 1);
//                   onChange('names', newNames);
//                 }}
//                 isParent={false}
//               />
//             </AccordionDetails>
//           </Accordion>
//         ))}

//       <Button
//         variant="contained"
//         color="primary"
//         startIcon={<AddCircleIcon />}
//         onClick={handleAddSubForm}
//       >
//         Add Sub-Form
//       </Button>

//       <Button
//         className="mx-4"
//         variant="contained"
//         color="error"
//         startIcon={<DeleteIcon />}
//         onClick={onRemoveSubForm}
//       >
//         Remove Sub-Form
//       </Button>

//       <Dialog open={openDialog} onClose={handleDialogClose}>
//         <DialogTitle>Edit Option</DialogTitle>
//         <DialogContent>
//           {formData.names &&
//             formData.names.map((name, index) => (
//               <div key={index}>
//                 <TextField
//                   label={`Option ${index + 1}`}
//                   required
//                   value={name.Option}
//                   onChange={(e) => {
//                     const newNames = [...formData.names];
//                     newNames[index].Option = e.target.value;
//                     onChange('names', newNames);
//                   }}
//                   variant="outlined"
//                   fullWidth
//                   margin="normal"
//                 />
//                 <TextField
//                   label={`Question ${index + 1}`}
//                   required
//                   value={name.Question}
//                   onChange={(e) => {
//                     const newNames = [...formData.names];
//                     newNames[index].Question = e.target.value;
//                     onChange('names', newNames);
//                   }}
//                   variant="outlined"
//                   fullWidth
//                   margin="normal"
//                 />
//                 <TextField
//                   label={`Label ${index + 1}`}
//                   required
//                   value={name.Label}
//                   onChange={(e) => {
//                     const newNames = [...formData.names];
//                     newNames[index].Label = e.target.value;
//                     onChange('names', newNames);
//                   }}
//                   variant="outlined"
//                   fullWidth
//                   margin="normal"
//                 />
//               </div>
//             ))}
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleDialogClose} color="primary">
//             Save
//           </Button>
//           <Button onClick={handleDialogClose} color="secondary">
//             Cancel
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </div>
//   );
// };

// const ContactForm = () => {
//   const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);

//   const handleChange = (index, field, value) => {
//     setForms((prevForms) => {
//       const newForms = [...prevForms];
//       newForms[index][field] = value;
//       return newForms;
//     });
//   };

//   const addSubForm = (formData) => {
//     if (!formData.names) {
//       formData.names = [];
//     }
//     formData.names.push({ Option: '', Question: '', Label: '' });
//     setForms([...forms]);
//   };

//   const removeParentForm = (index) => {
//     const newForms = [...forms];
//     newForms.splice(index, 1);
//     setForms(newForms);
//   };

//   const handleSubmit = () => {
//     console.log('Form Data:', forms);
//     console.log('length:', forms.length);
//     // You can perform additional actions with the form data here.
//   };

//   return (
//     <div>
//       <br />
//       <h1>Add work and sub work</h1>
//       <div>
//         <SubForm
//           formData={forms[0]}
//           onChange={(field, value) => handleChange(0, field, value)}
//           onAddSubForm={() => addSubForm(forms[0])}
//           onRemoveSubForm={() => removeParentForm(0)}
//           isParent={true}
//         />
//         <Button
//           variant="contained"
//           color="error"
//           startIcon={<DeleteIcon />}
//           onClick={() => removeParentForm(0)}
//         >
//           Remove Parent Form0
//         </Button>
//       </div>

//       {forms.length === 0 ? (
//         <Button
//           variant="contained"
//           color="primary"
//           onClick={() =>
//             setForms([...forms, { Option: '', names: [], Question: '' }])
//           }
//         >
//           Add Parent Form
//         </Button>
//       ) : (
//         ''
//       )}
//       <Button variant="contained" color="primary" onClick={handleSubmit}>
//         Submit
//       </Button>
//     </div>
//   );
// };

// export default ContactForm;
