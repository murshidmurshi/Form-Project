import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import DeleteIcon from '@mui/icons-material/Delete';

const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dialogData, setDialogData] = useState({ Question: '', Option: '', Label: '' });

  const handleOpenDialog = () => {
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
  };

  const handleSubmitDialog = () => {
    // Ensure formData.names is an array
    const newNames = Array.isArray(formData.names) ? [...formData.names] : [];

    // Add the dialogData to the array
    newNames.push(dialogData);

    // Update the formData with the new names array
    onChange('names', newNames);

    setIsDialogOpen(false);
    setDialogData({ Question: '', Option: '', Label: '' }); // Clear the dialog input fields
  };

  return (
    <div>
      <div style={{ border: '2px solid black', borderRadius: '20px', padding: '10px', margin: '10px', backgroundColor: isParent ? 'lightblue' : 'lightgreen' }}>
        {!isParent && (
          <TextField
            label="Option"
            required
            onChange={(e) => onChange('Option', e.target.value)}
            variant="outlined"
            fullWidth
            margin="normal"
          />
        )}

        <TextField
          label="Question"
          required
          value={formData.Question}
          onChange={(e) => onChange('Question', e.target.value)}
          variant="outlined"
          fullWidth
          margin="normal"
        />

        {formData.names && formData.names.map((subFormData, index) => (
          <SubForm
            key={index}
            formData={subFormData}
            onChange={(field, value) => {
              const newNames = [...formData.names];
              newNames[index][field] = value;
              onChange('names', newNames);
            }}
            onAddSubForm={onAddSubForm}
            onRemoveSubForm={() => {
              const newNames = [...formData.names];
              newNames.splice(index, 1);
              onChange('names', newNames);
            }}
          />
        ))}

        <Button variant="contained" color="primary" startIcon={<AddCircleIcon />} onClick={handleOpenDialog}>
          Add Sub-Form
        </Button>

        {!isParent && (
          <Button className='mx-4' variant="contained" color="error" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
            Remove Sub-Form
          </Button>
        )}
      </div>

      <Dialog open={isDialogOpen} onClose={handleCloseDialog}>
        <DialogTitle>Add Question, Option, and Label</DialogTitle>
        <DialogContent>
          <TextField
            label="Question"
            required
            value={dialogData.Question}
            onChange={(e) => setDialogData({ ...dialogData, Question: e.target.value })}
            variant="outlined"
            fullWidth
            margin="normal"
          />

          {/* Option should be set in the dialogData, not in the current form */}
          <TextField
            label="Option"
            required
            value={dialogData.Option}
            onChange={(e) => setDialogData({ ...dialogData, Option: e.target.value })}
            variant="outlined"
            fullWidth
            margin="normal"
          />

          <TextField
            label="Label"
            required
            value={dialogData.Label}
            onChange={(e) => setDialogData({ ...dialogData, Label: e.target.value })}
            variant="outlined"
            fullWidth
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmitDialog} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

const ContactForm = () => {
  const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);

  const handleChange = (index, field, value) => {
    setForms(prevForms => {
      const newForms = [...prevForms];
      newForms[index][field] = value;
      return newForms;
    });
  };

  const addSubForm = (formData) => {
    // Ensure formData.names is an array
    const namesArray = Array.isArray(formData.names) ? formData.names : [];
    namesArray.push({ Option: '', Question: '', Label: '' });

    // Update formData with the new namesArray
    formData.names = namesArray;

    setForms([...forms]);
  };

  const removeParentForm = (index) => {
    const newForms = [...forms];
    newForms.splice(index, 1);
    setForms(newForms);
  };

  const handleSubmit = () => {
    console.log('Form Data:', forms);
    console.log('length:', forms.length);
    // You can perform additional actions with the form data here.
  };

  return (
    <div>
      <br />
      <h1>Add work and sub work</h1>
      {forms.map((form, index) => (
        <div key={index}>
          <SubForm
            formData={form}
            onChange={(field, value) => handleChange(index, field, value)}
            onAddSubForm={() => addSubForm(form)}
            onRemoveSubForm={() => removeParentForm(index)}
            isParent={index === 0}
          />
          {index !== 0 && (
            <Button
              variant="contained"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={() => removeParentForm(index)}
            >
              Remove Parent Form0
            </Button>
          )}
        </div>
      ))}

      {forms.length === 0 ? (
        <Button
          variant="contained"
          color="primary"
          onClick={() => setForms([...forms, { Option: '', Question: '', names: [] }])}
        >
          Add Parent Form
        </Button>
      ) : ''}
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Submit
      </Button>
    </div>
  );
};

export default ContactForm;
