


import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import DeleteIcon from '@mui/icons-material/Delete';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';


const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
  let [addtext, setAddtext] = useState(true)


  // let [ADDoption,setADDoption] =useState(false)

  const containerStyle = {
    // border: '2px solid black',
    borderRadius: '20px',

    backgroundColor: isParent ? 'lightblue' : 'lightgreen',
  };

  const addButtonStyle = {
    backgroundColor: isParent ? 'lightblue' : 'lightgreen',
  };

  const handleAddSubForm = () => {
    const newFormData = { Option: '', Question: '', names: [] };
    onChange('names', [...formData.names, newFormData]);
    setAddtext(false)



    // setADDoption(true)

  };

  const ADDTEXT = () => {
    setAddtext(true)
    // console.log('Add Text')
  }


  return (


    <div style={containerStyle}>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls={`panel${'s'}-content`}
          id={`panel${'s'}-header`}
        >
        </AccordionSummary>
        <AccordionDetails>

          <div style={{position:'relative',bottom:'80px'}}>
            {!isParent && (
              <TextField

                label="Option"
                required

                // value={formData.name}
                onChange={(e) => onChange('Option', e.target.value)}
                variant="outlined"
                fullWidth
                margin="normal"
              />


            )}
          </div>
          <TextField
            label="Question"
            required
            value={formData.name}
            onChange={(e) => onChange('Question', e.target.value)}
            variant="outlined"
            fullWidth
            margin="normal"
          />

          {addtext ?
            !isParent && (
              <TextField
                label="LABEL"
                required
                value={formData.name}
                onChange={(e) => onChange('TEXT', e.target.value)}
                variant="outlined"
                fullWidth
                margin="normal"
              />
            )
            : ''}

        </AccordionDetails>
      </Accordion>





      {formData.names &&
        formData.names.map((name, index) => (
          <div>
            <SubForm
              key={index}
              formData={name}
              onChange={(field, value) => {
                const newNames = [...formData.names];
                newNames[index][field] = value;
                onChange('names', newNames);
              }}
              onAddSubForm={onAddSubForm}
              onRemoveSubForm={() => {
                const newNames = [...formData.names];
                newNames.splice(index, 1);
                onChange('names', newNames);
              }}
            />
            <br />
          </div>
        ))}
      {/* <Button onClick={()=>setAddtext(true)}>AddTEXT</Button> */}

      <Button variant="contained" color="primary" startIcon={<AddCircleIcon />} /* style={addButtonStyle}  */ onClick={handleAddSubForm}>
        Add Sub-Form
      </Button>

      <Button className='mx-4' variant="contained" color="error" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
        Remove Sub-Form
      </Button>
    </div>
  );
};


let aaa;
let bbb;


const ContactForm = () => {
  const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);
  // aaa = {forms, setForms}
  aaa = forms
  bbb = setForms

  const handleChange = (index, field, value) => {
    setForms(prevForms => {
      const newForms = [...prevForms];
      newForms[index][field] = value;
      return newForms;
    });
  };


  const addSubForm = (formData) => {
    if (!formData.names) {
      formData.names = [];
    }
    formData.names.push({ Option: '', Question: '', names: [] });
    setForms([...forms]);


  };

  const removeParentForm = (index) => {
    const newForms = [...forms];
    newForms.splice(index, 1);
    setForms(newForms);
  };

  const handleSubmit = () => {
    console.log('Form Data:', forms);
    console.log('length:', forms.length);
    // You can perform additional actions with the form data here.
  };

  return (
    <div>
      <br />
      <h1>Add work and sub work</h1>
      {forms.map((form, index) => (
        <div key={index}>

          <SubForm
            formData={form}
            onChange={(field, value) => handleChange(index, field, value)}
            onAddSubForm={() => addSubForm(form)}
            onRemoveSubForm={() => removeParentForm(index)}
            isParent={index === 0}
          />


          {index !== 0 && (
            <Button
              variant="contained"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={() => removeParentForm(index)}
            >
              Remove Parent Form0
            </Button>
          )}
        </div>
      ))}


      {forms.length == 0 ? (
        <Button variant="contained" color="primary" onClick={() => setForms([...forms, { Option: '', Question: '', names: [] }])}>
          Add Parent Form
        </Button>
      ) : ''}
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Submit
      </Button>
    </div>
  );
};




export { aaa, bbb }
export default ContactForm;
