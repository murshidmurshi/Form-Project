// import React from 'react'
// import { useState } from 'react'
// import Button from '@mui/material/Button';
// import DeleteIcon from '@mui/icons-material/Delete';

// import { TextField } from '@mui/material';


// const SubForm = ({ formData, onChange, onAddSubform, onRemoveSubform }) => {
//     const containerStyle = {
//         border: '1px solid black',
//         padding: '10px',
//         margin: '10px',
//         backgroundColor: 'lighblue'

//     }
//     const handleAddSubFrom = () => {
//         const newFormData = { name: '', names: [] }
//         onChange('names', [...formData.names, newFormData])
//     }
//     return (
//         <div style={containerStyle}>
//             <TextField
//                 label={'Name'}
//                 onChange={(e)=>onChange('name',e.target.value)}
//                 value={formData.name}
//                 fullWidth />

//             {formData.names &&
//                 formData.names.map((name, index) => (
//                     <SubForm
//                         formData={name}
//                         onChange={(field, value) => {
//                             const newNames = [...formData.names]
//                             newNames[index][field] = value
//                             onChange('names', newNames)
//                         }}
//                         onAddSubform={onAddSubform}
//                         onRemoveSubform={() => {
//                             const newNames = [...formData.names]
//                             newNames.splice(index, 1)
//                             onChange('names', newNames)
//                         }}
//                     />

//                 ))}




//             <Button variant='contained' color='success' onClick={handleAddSubFrom} >Add Sub-Form</Button>

//             <Button variant='contained' color='secondary' onClick={onRemoveSubform} startIcon={<DeleteIcon />}>Remove Sub-Form</Button>
//         </div>

//     )
// }



// export default function TRYForm() {
//     const [forms, setForms] = useState([{ name: '', names: '' }])

//     const handleChange = (index, field, value) => {
//         setForms(prevForm => {
//             const newForms = [...prevForm]
//             newForms[index][field] = value;
//             return newForms
//         })
//     }

//     const Submit = () => {
//         console.log(forms)
//     }
//     const addSubform = (formData) => {
//         console.log('addSubform')
//         if (!formData.names) {
//             formData.names = []

//         }
//         formData.names.push({ name: '', names: [] })
//         setForms([...forms])
//     }

//     const removeParentForm = (index) => {
//         const newForm = [...forms]
//         newForm.splice(index, 1)
//         setForms(newForm)

//     }
//     return (
//         <>
//             <div>
//                 <h1>Contact Info</h1>
//                 {forms.map((form, index) => {
//                     return (
//                         <>
//                             <SubForm
//                                 formData={form}
//                                 onChange={(field, value) => handleChange(index, field, value)}
//                                 onAddSubform={() => addSubform(form)}
//                                 onRemoveSubform={() => removeParentForm(index)}
//                             />
//                             {index !== 0 && (
//                                 <Button
//                                     variant='contained'
//                                     color='secondary'
//                                     startIcon={<DeleteIcon />}
//                                     onClick={() => removeParentForm(index)}
//                                 >Remove Parent Form</Button>
//                             )}

//                         </>
//                     )

//                 })}


//                 <br />
//                 <Button className='mt-4' variant='contained' onClick={() => setForms([...forms, { name: '', names: [] }])}>Add Parent Button</Button>
//                 <br />
//                 <Button onClick={Submit}>Submit</Button>



//             </div>
//         </>
//     )
// }


// import { TextField } from '@mui/material'
// import React from 'react'
// import { useState } from 'react'
// import Button from '@mui/material/Button'
// import DynamicSelector from './DynamicSelector'

// const SubForm = ({ formData, onChange, onAddSubform, removeSubForm, isParent }) => {

//     const containerStyle = {
//         border: '1px solid ',
//         padding: '10px',
//         margin: '10px',
//         backgroundColor: isParent ? 'lightgreen' : 'lightblue'


//     }
//     const addButtonStyle = {
//         backgroundColor: isParent ? 'lightblue' : 'lightgreen'
//     }

//     const handleSubform = () => {
//         // console.log('Gi')
//         const newNames = { name: '', names: [] }
//         onChange('names', [...formData.names, newNames])
//     }


//     return (
//         <div style={containerStyle}>
//             <TextField
//                 label='Name *'
//                 fullWidth
//                 variant="outlined"
//                 value={formData.name}
//                 onChange={(e) => onChange('name', e.target.value)}

//             />
//             {/* <DynamicSelector /> */}

//             {formData.names && (
//                 formData.names.map((name, index) => {
//                     return (
//                         <>
//                             <SubForm
//                                 formData={(name)}
//                                 onChange={(field, value) => {
//                                     const newNames = [...formData.names]
//                                     newNames[index][field] = value
//                                     onChange('names', newNames)
//                                 }}
//                                 onAddSubform={onAddSubform}
//                                 removeSubForm={() => {
//                                     const newNames = [...formData.names]
//                                     newNames.splice(index, 1)
//                                     onChange('names', newNames)
//                                 }}
//                                 isParent={index == 0}

//                             />
//                         </>
//                     )
//                 })
//             )}


//             <Button color='primary' variant='contained' style={addButtonStyle} onClick={handleSubform} >Add Sub Form</Button>
//             <Button color='secondary' variant='contained' onClick={removeSubForm}>Remove Sub Form</Button>
//             <br />

//         </div>

//     )
// }

// export default function TRYForm() {
//     const [forms, setForms] = useState([{ name: '', names: [] }])

//     const handleChange = (index, field, value) => {
//         setForms(prevfield => {
//             const newNames = [...prevfield]
//             newNames[index][field] = value
//             return newNames
//         })
//     }

//     const addSubForm = (formData) => {
//         console.log('ADDD')
//         if (!formData.names) {
//             formData.names = []
//         }
//         formData.names.push({ name: '', names: [] })
//         setForms([...forms])

//     }
//     const RemoveParentform = (index) => {
//         const newForm = [...forms]
//         newForm.splice(index, 1)
//         setForms(newForm)

//     }

//     const Submit = () => {
//         console.log(forms)
//     }
//     return (
//         <>
//             <div>
//                 <h1>Contact Information</h1>
//                 {forms.map((form, index) => {
//                     return (
//                         <>
//                             <SubForm
//                                 formData={form}
//                                 onChange={(field, value) => handleChange(index, field, value)}
//                                 onAddSubform={() => addSubForm(forms)}
//                                 removeSubForm={() => RemoveParentform(index)}

//                             />

//                             {index !== 0 && (
//                                 <Button color='secondary' variant='contained' onClick={() => RemoveParentform(index)}>Remove Parent Form</Button>
//                             )}
//                         </>
//                     )
//                 })}

//                 <Button color='success' variant='contained' onClick={() => setForms([...forms, { name: '', names: [] }])}>Add Parent Form</Button>



//                 <br />
//                 <Button variant='contained' color='primary' onClick={Submit} >Submit</Button>
//             </div>

//         </>
//     )
// }
// TRYForm.jsx



// import React, { useState } from 'react';
// import SubForm from '../Component/Sub';

// const TRYForm = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     options: [],
//     names: [],
//     question: '',
//   });

//   const handleChange = (field, value) => {
//     setFormData((prevFormData) => ({
//       ...prevFormData,
//       [field]: value,
//     }));
//   };

//   const handleAddSubform = () => {
//     const newSubForm = { name: '', names: [], question: '', options: [] };
//     handleChange('names', [...formData.names, newSubForm]);
//   };

//   const handleRemoveSubform = (index) => {
//     const newSubForms = [...formData.names];
//     newSubForms.splice(index, 1);
//     handleChange('names', newSubForms);
//   };

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     console.log(formData); // Log the form data when the submit button is clicked
//   };

//   return (
//     <div>
//       <SubForm
//         formData={formData}
//         onChange={handleChange}
//         onAddSubform={handleAddSubform}
//         removeSubForm={handleRemoveSubform}
//         isParent={true}
//       />
//       <button type="submit" onClick={handleSubmit}>Submit</button>
//     </div>
//   );
// };

// export default TRYForm;




import React, { useState } from 'react';
import SubForm from '../Component/Sub';

const TRYForm = ({ onFormSubmit }) => {
    const [formData, setFormData] = useState({
        name: '',
        options: [],
        names: [],
        question: '',
    });

    const handleChange = (field, value) => {
        setFormData((prevFormData) => ({
            ...prevFormData,
            [field]: value,
        }));
    };

    const handleAddSubform = () => {
        const newSubForm = { name: '', names: [], question: '', options: [] };
        handleChange('names', [...formData.names, newSubForm]);
    };

    const handleRemoveSubform = (index) => {
        const newSubForms = [...formData.names];
        newSubForms.splice(index, 1);
        handleChange('names', newSubForms);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(formData);
        onFormSubmit(formData);
    };

    return (
        <div>
            <form >
                <SubForm
                    formData={formData}
                    onChange={handleChange}
                    onAddSubform={handleAddSubform}
                    removeSubForm={handleRemoveSubform}
                    isParent={true}
                />
                {/* <button type="submit">Submit</button> */}
            </form>
        </div>
    );
};

export default TRYForm;
