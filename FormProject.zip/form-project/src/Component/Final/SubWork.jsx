import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import DeleteIcon from '@mui/icons-material/Delete';

const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {
    const [addtext, setAddtext] = useState(true);

    const containerStyle = {
        border: '2px solid black',
        borderRadius: '20px',
        padding: '10px',
        margin: '10px',
        backgroundColor: isParent ? 'lightblue' : 'lightgreen',
    };

    const addButtonStyle = {
        backgroundColor: isParent ? 'lightblue' : 'lightgreen',
    };

    const handleAddSubForm = (type) => {
        const newFormData = type === 'Option' ? { Option: '', names: [] } : { Question: '', names: [] };
        onChange('names', [...formData.names, newFormData]);
        setAddtext(false);
    };

    const ADDTEXT = () => {
        setAddtext(true);
    };

    return (
        <div style={containerStyle}>
            {!isParent && (
                <TextField
                    label="Option"
                    required
                    value={formData.Option}
                    onChange={(e) => onChange('Option', e.target.value)}
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            )}

            {!isParent && (
                <TextField
                    label="Question"
                    required
                    value={formData.Question}
                    onChange={(e) => onChange('Question', e.target.value)}
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            )}

            {addtext ? (
                !isParent && (
                    <TextField
                        label="LABEL"
                        required
                        value={formData.TEXT}
                        onChange={(e) => onChange('TEXT', e.target.value)}
                        variant="outlined"
                        fullWidth
                        margin="normal"
                    />
                )
            ) : (
                ''
            )}

            {formData.names &&
                formData.names.map((name, index) => (
                    <SubForm
                        key={index}
                        formData={name}
                        onChange={(field, value) => {
                            const newNames = [...formData.names];
                            newNames[index][field] = value;
                            onChange('names', newNames);
                        }}
                        onAddSubForm={onAddSubForm}
                        onRemoveSubForm={() => {
                            const newNames = [...formData.names];
                            newNames.splice(index, 1);
                            onChange('names', newNames);
                        }}
                    />
                ))}

            {!isParent && (
                <>
                    <Button variant="contained" color="primary" startIcon={<AddCircleIcon />} onClick={() => handleAddSubForm('Option')}>
                        Add Option Sub-Form
                    </Button>
                    <Button variant="contained" color="primary" startIcon={<AddCircleIcon />} onClick={() => handleAddSubForm('Question')}>
                        Add Question Sub-Form
                    </Button>
                </>
            )}
        </div>
    );
};

const ContactForm = () => {
    const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);

    const handleChange = (index, field, value) => {
        setForms((prevForms) => {
            const newForms = [...prevForms];
            newForms[index][field] = value;
            return newForms;
        });
    };

    const removeParentForm = (index) => {
        const newForms = [...forms];
        newForms.splice(index, 1);
        setForms(newForms);
    };

    const handleSubmit = () => {
        console.log('Form Data:', forms);
        console.log('length:', forms.length);
        // You can perform additional actions with the form data here.
    };

    return (
        <div>
            <br />
            <h1>Add work and sub work</h1>
            {forms.map((form, index) => (
                <div key={index}>
                    <SubForm
                        formData={form}
                        onChange={(field, value) => handleChange(index, field, value)}
                        onRemoveSubForm={() => removeParentForm(index)}
                        isParent={index === 0}
                    />
                </div>
            ))}

            {forms.length === 0 ? (
                <Button variant="contained" color="primary" onClick={() => setForms([...forms, { Option: '', Question: '', names: [] }])}>
                    Add Parent Form
                </Button>
            ) : (
                ''
            )}
            <Button variant="contained" color="primary" onClick={handleSubmit}>
                Submit
            </Button>
        </div>
    );
};

export default ContactForm;
