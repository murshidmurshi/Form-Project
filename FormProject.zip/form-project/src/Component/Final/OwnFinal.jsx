

// import React, { useState } from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import AddCircleIcon from '@mui/icons-material/AddCircle';
// import DeleteIcon from '@mui/icons-material/Delete';
// import './sub.css'

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {

//     const handleAddSubForm = () => {

//         const newFormData = { Option: '', Question: '', names: [] };
//         onChange('names', [...formData.names, newFormData]);


//     };


//     const [Makequestion, setMakeQuestion] = useState(false)
//     const [makeFieldtrue, setMakeFieldTrue] = useState(false)
//     const [openOption, setOpenOption] = useState(false)


//     const [makefalseaddQuestion, setMakeFalseAddQuestion] = useState(true)
//     // const [makeFalseFieldQuestion, setMakeFalseFieldQuestion] = useState(true)

//     const [MainOption, setMainOption] = useState(false)

//     const [normalquestion, setNormalQuestion] = useState(false)

//     const [MainQuestion, setMainQuestion] = useState('')
//     const [fieldlabel, setFieldLabel] = useState('')



//     const ADDQuestion = () => {
//         console.log('ADDQuestionBtn Clicked')
//         setMakeQuestion(true)
//         setMakeFalseAddQuestion(false)

//     }
//     //for field
//     const ADDField = () => {
//         console.log('AddField Clicked')
//         // setMakeQuestion(true)
//         setMakeFieldTrue(true)
//         setMakeFalseAddQuestion(false)
//     }



//     const SAVE = () => {
//         console.log('SAVE')
//         console.log(formData.Question)
//         setMainQuestion(formData.Question)
//         setOpenOption(true)

//     }

//     const SAVEField = () => {
//         console.log('SAVEField')
//         console.log(formData.TEXT)
//         // setMainQuestion(formData.label)
//         setFieldLabel(formData.TEXT)
//         setOpenOption(false)
//     }

//     const SAVE2 = () => {
//         console.log('SAVE')
//         console.log(formData.Option)
//         setMainOption(formData.Option)
//         // setOpenOption(true)
//     }
//     const SAVE3 = () => {
//         console.log('SAVE')
//         console.log(formData.Question)
//         setNormalQuestion(formData.Question)
//         setOpenOption(true)

//     }

//     return (
//         <>
//             {/* <div className="firstBtn">
//                 <Button variant='contained' color='success'>
//                     Add Question

//                 </Button>        </div> */}
//             <div className='mainContainer'>


//                 {MainOption ? (
//                     <>
//                         <span style={{ fontSize: '25px', marginRight: '100px' }}>  {MainOption}</span>

//                         {makefalseaddQuestion && (
//                             <>
//                                 <Button variant='contained' color='secondary' style={{ marginRight: '20px' }} onClick={ADDQuestion}>AddQuestion</Button>
//                                 <Button variant='contained' color='success' onClick={ADDField}>AddField</Button>
//                             </>

//                         )}


//                         <br />
//                     </>

//                 ) :
//                     !isParent && (
//                         <>
//                             <input

//                                 label="Option"
//                                 required

//                                 // value={formData.name}
//                                 placeholder='Enter Option'
//                                 onChange={(e) => onChange('Option', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                             />
//                             <Button variant='contained' color='success' className='save' onClick={SAVE2}>Save</Button>

//                         </>

//                     )
//                 }

//                 {MainQuestion ? (
//                     <h1 style={{ fontWeight: '500', fontSize: '30px' }}>Q:{MainQuestion}</h1>
//                 ) :
//                     isParent && (
//                         <><h1 style={{ display: 'inline' }}>Q:</h1>
//                             <input
//                                 label="Question"
//                                 required
//                                 value={formData.name}
//                                 onChange={(e) => onChange('Question', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                                 placeholder='Enter Main Question'
//                             />
//                             <Button variant='contained' color='success' className='save' onClick={SAVE}>Save</Button>

//                         </>

//                     )

//                 }

//                 {normalquestion ? (
//                     <span style={{ fontSize: '25px', marginRight: '100px' }}>{normalquestion}</span>

//                 ) :
//                     Makequestion &&
//                     (
//                         <>
//                             <input
//                                 label="Question"
//                                 required
//                                 value={formData.name}
//                                 onChange={(e) => onChange('Question', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                                 placeholder='Enter Question'
//                             />
//                             <Button variant='contained' color='success' className='save' onClick={SAVE3}>Save</Button>


//                         </>

//                     )

//                 }


//                 {fieldlabel ? (
//                     <span style={{ fontSize: '25px', marginRight: '100px' }}>{fieldlabel}</span>

//                 ) :
//                     makeFieldtrue && (
//                         <>
//                             <input
//                                 label="LABEL"
//                                 required
//                                 value={formData.name}
//                                 onChange={(e) => onChange('TEXT', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                                 placeholder='Enter Field'
//                             />
//                             <Button variant='contained' color='success' onClick={SAVEField}>Save</Button>
//                         </>
//                     )
//                 }



//                 {/* {addtext ?
//                 !isParent && (


//                 )
//                 : ''} */}


//                 {formData.names &&
//                     formData.names.map((name, index) => (
//                         <SubForm
//                             key={index}
//                             formData={name}
//                             onChange={(field, value) => {
//                                 const newNames = [...formData.names];
//                                 newNames[index][field] = value;
//                                 onChange('names', newNames);
//                             }}
//                             onAddSubForm={onAddSubForm}
//                             onRemoveSubForm={() => {
//                                 const newNames = [...formData.names];
//                                 newNames.splice(index, 1);
//                                 onChange('names', newNames);
//                             }}
//                         />
//                     ))}
//                 {/* <Button onClick={()=>setAddtext(true)}>AddTEXT</Button> */}

//                 {openOption && (
//                     <Button variant="contained" color="primary" startIcon={<AddCircleIcon />} /* style={addButtonStyle}  */ onClick={handleAddSubForm}>
//                         {/* Add Sub-Form */}ADD OPTION
//                     </Button>
//                 )}

//                 {/* <Button className='mx-4' variant="contained" color="error" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
//                 Remove Sub-Form
//             </Button> */}
//             </div>
//         </>

//     );
// };


// let aaa;
// let bbb;


// const ContactForm = () => {
//     const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);
//     // aaa = {forms,setForms}
//     aaa = forms
//     bbb = setForms

//     const handleChange = (index, field, value) => {
//         setForms(prevForms => {
//             const newForms = [...prevForms];
//             newForms[index][field] = value;
//             return newForms;
//         });
//     };


//     const addSubForm = (formData) => {
//         if (!formData.names) {
//             formData.names = [];
//         }
//         formData.names.push({ Option: '', Question: '', names: [] });
//         setForms([...forms]);


//     };

//     const removeParentForm = (index) => {
//         const newForms = [...forms];
//         newForms.splice(index, 1);
//         setForms(newForms);
//     };

//     const handleSubmit = () => {
//         console.log('Form Data:', forms);
//         console.log('length:', forms.length);
//         // You can perform additional actions with the form data here.
//     };

//     return (
//         <div>
//             <br />
//             <p style={{ fontSize: '30px' }}>Add work and sub work</p>
//             {forms.map((form, index) => (
//                 <div key={index}>

//                     <SubForm
//                         formData={form}
//                         onChange={(field, value) => handleChange(index, field, value)}
//                         onAddSubForm={() => addSubForm(form)}
//                         onRemoveSubForm={() => removeParentForm(index)}
//                         isParent={index === 0}
//                     />


//                     {index !== 0 && (
//                         <Button
//                             variant="contained"
//                             color="error"
//                             startIcon={<DeleteIcon />}
//                             onClick={() => removeParentForm(index)}
//                         >
//                             Remove Parent Form0
//                         </Button>
//                     )}
//                 </div>
//             ))}


//             {forms.length == 0 ? (
//                 <Button variant="contained" color="primary" onClick={() => setForms([...forms, { Option: '', Question: '', names: [] }])}>
//                     Add Parent Form
//                 </Button>
//             ) : ''}
//             <Button variant="contained" color="primary" onClick={handleSubmit}>
//                 Submit
//             </Button>
//         </div>
//     );
// };




// export { aaa, bbb }
// export default ContactForm;











import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import DeleteIcon from '@mui/icons-material/Delete';
import './sub.css'
import Muitable from './MuiTable';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';


const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {

    const handleAddSubForm = () => {

        const newFormData = { Option: '', Question: '', names: [] };
        onChange('names', [...formData.names, newFormData]);


    };


    const [Makequestion, setMakeQuestion] = useState(false)
    const [makeFieldtrue, setMakeFieldTrue] = useState(false)
    const [openOption, setOpenOption] = useState(false)


    const [makefalseaddQuestion, setMakeFalseAddQuestion] = useState(true)
    // const [makeFalseFieldQuestion, setMakeFalseFieldQuestion] = useState(true)

    const [MainOption, setMainOption] = useState(false)

    const [normalquestion, setNormalQuestion] = useState(false)

    const [MainQuestion, setMainQuestion] = useState('')
    const [fieldlabel, setFieldLabel] = useState('')



    const ADDQuestion = () => {
        console.log('ADDQuestionBtn Clicked')
        setMakeQuestion(true)
        setMakeFalseAddQuestion(false)

    }
    //for field
    const ADDField = () => {
        console.log('AddField Clicked')
        // setMakeQuestion(true)
        setMakeFieldTrue(true)
        setMakeFalseAddQuestion(false)
    }



    const SAVE = () => {
        console.log('SAVE')
        console.log(formData.Question)
        setMainQuestion(formData.Question)
        setOpenOption(true)

    }

    const SAVEField = () => {
        console.log('SAVEField')
        console.log(formData.TEXT)
        // setMainQuestion(formData.label)
        setFieldLabel(formData.TEXT)
        setOpenOption(false)
    }

    const SAVE2 = () => {
        console.log('SAVE')
        console.log(formData.Option)
        setMainOption(formData.Option)
        // setOpenOption(true)
    }
    const SAVE3 = () => {
        console.log('SAVE')
        console.log(formData.Question)
        setNormalQuestion(formData.Question)
        setOpenOption(true)

    }

    return (
        <>
            {/* <div className="firstBtn">
                <Button variant='contained' color='success'>
                    Add Question

                </Button>        </div> */}
            <div className='mainContainer'>

                <div style={{position:'relative',bottom:'80px'}}>
                    {MainOption ? (
                        <>
                            <span style={{ fontSize: '25px', marginRight: '100px' }}>  {MainOption}</span>

                            {makefalseaddQuestion && (
                                <>
                                    <Button variant='contained' color='secondary' style={{ marginRight: '20px' }} onClick={ADDQuestion}>AddQuestion</Button>
                                    <Button variant='contained' color='success' onClick={ADDField}>AddField</Button>
                                </>

                            )}


                            <br />
                        </>

                    ) :
                        !isParent && (
                            <>
                                <input

                                    label="Option"
                                    required

                                    // value={formData.name}
                                    placeholder='Enter Option'
                                    onChange={(e) => onChange('Option', e.target.value)}
                                    variant="outlined"
                                    fullWidth
                                    margin="normal"
                                />
                                <Button variant='contained' color='success' className='save' onClick={SAVE2}>Save</Button>

                            </>

                        )
                    }

                </div>

                {MainQuestion ? (
                    <h1 style={{ fontWeight: '500', fontSize: '30px' }}>Q:{MainQuestion}</h1>
                ) :
                    isParent && (
                        <><h1 style={{ display: 'inline' }}>Q:</h1>
                            <input
                                label="Question"
                                required
                                value={formData.name}
                                onChange={(e) => onChange('Question', e.target.value)}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                placeholder='Enter Main Question'
                            />
                            <Button variant='contained' color='success' className='save' onClick={SAVE}>Save</Button>

                        </>

                    )

                }

                {normalquestion ? (
                    <span style={{ fontSize: '25px', marginRight: '100px' }}>{normalquestion}</span>

                ) :
                    Makequestion &&
                    (
                        <>
                            <input
                                label="Question"
                                required
                                value={formData.name}
                                onChange={(e) => onChange('Question', e.target.value)}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                placeholder='Enter Question'
                            />
                            <Button variant='contained' color='success' className='save' onClick={SAVE3}>Save</Button>


                        </>

                    )

                }


                {fieldlabel ? (
                    <span style={{ fontSize: '25px', marginRight: '100px' }}>{fieldlabel}</span>

                ) :
                    makeFieldtrue && (
                        <>
                            <input
                                label="LABEL"
                                required
                                value={formData.name}
                                onChange={(e) => onChange('TEXT', e.target.value)}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                placeholder='Enter Field'
                            />
                            <Button variant='contained' color='success' onClick={SAVEField}>Save</Button>
                        </>
                    )
                }




                {formData.names &&
                    formData.names.map((name, index) => (
                        <Accordion key={index}>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls={`panel${index}-content`}
                                id={`panel${index}-header`}
                            >
                                {/* Render any additional information for each "names" entry here */}
                                {/* {name.Option} */}
                            </AccordionSummary>
                            <AccordionDetails>

                                <SubForm
                                    formData={name}
                                    onChange={(field, value) => {
                                        const newNames = [...formData.names];
                                        newNames[index][field] = value;
                                        onChange('names', newNames);
                                    }}
                                    onAddSubForm={onAddSubForm}
                                    onRemoveSubForm={() => {
                                        const newNames = [...formData.names];
                                        newNames.splice(index, 1);
                                        onChange('names', newNames);
                                    }}
                                />
                                <br />
                            </AccordionDetails>
                        </Accordion>
                    ))}

                {/* <Button onClick={()=>setAddtext(true)}>AddTEXT</Button> */}

                {openOption && (
                    <Button variant="contained" color="primary" startIcon={<AddCircleIcon />} /* style={addButtonStyle}  */ onClick={handleAddSubForm}>
                        {/* Add Sub-Form */}ADD OPTION
                    </Button>
                )}

                {/* <Button className='mx-4' variant="contained" color="error" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
                Remove Sub-Form
            </Button> */}
            </div>
        </>

    );
};


let aaa;
let bbb;


const ContactForm = () => {
    const [forms, setForms] = useState([{ Option: '', names: [], Question: '' }]);
    // aaa = {forms,setForms}
    aaa = forms
    bbb = setForms

    const handleChange = (index, field, value) => {
        setForms(prevForms => {
            const newForms = [...prevForms];
            newForms[index][field] = value;
            return newForms;
        });
    };


    const addSubForm = (formData) => {
        if (!formData.names) {
            formData.names = [];
        }
        formData.names.push({ Option: '', Question: '', names: [] });
        setForms([...forms]);


    };

    const removeParentForm = (index) => {
        const newForms = [...forms];
        newForms.splice(index, 1);
        setForms(newForms);
    };

    const handleSubmit = () => {
        console.log('Form Data:', forms);
        console.log('length:', forms.length);
        // You can perform additional actions with the form data here.
    };

    return (
        <>
            <div>
                <br />
                <p style={{ fontSize: '30px' }}>Add work and sub work</p>
                {forms.map((form, index) => (
                    <div key={index}>

                        <SubForm
                            formData={form}
                            onChange={(field, value) => handleChange(index, field, value)}
                            onAddSubForm={() => addSubForm(form)}
                            onRemoveSubForm={() => removeParentForm(index)}
                            isParent={index === 0}
                        />


                        {index !== 0 && (
                            <Button
                                variant="contained"
                                color="error"
                                startIcon={<DeleteIcon />}
                                onClick={() => removeParentForm(index)}
                            >
                                Remove Parent Form0
                            </Button>
                        )}
                    </div>
                ))}


                {forms.length == 0 ? (
                    <Button variant="contained" color="primary" onClick={() => setForms([...forms, { Option: '', Question: '', names: [] }])}>
                        Add Parent Form
                    </Button>
                ) : ''}
                <Button variant="contained" color="primary" onClick={handleSubmit}>
                    Submit
                </Button>
            </div>
            {/* <Muitable forms={forms} /> */}
        </>
    );
};




export { aaa, bbb }
export default ContactForm;








//LocalstorageSET

// import React, { useEffect, useState } from 'react';
// import TextField from '@mui/material/TextField';
// import Button from '@mui/material/Button';
// import AddCircleIcon from '@mui/icons-material/AddCircle';
// import DeleteIcon from '@mui/icons-material/Delete';
// import './sub.css'

// import Muitable from './MuiTable';
// let countCopy;

// const SubForm = ({ formData, onChange, onAddSubForm, onRemoveSubForm, isParent }) => {

//     const [open, setOpen] = React.useState(false);

//     const handleAddSubForm = () => {
//         setOpen(true);

//         const newFormData = { Option: '', Question: '', names: [] };
//         onChange('names', [...formData.names, newFormData]);
//         setCount(count + 1)


//     };


//     const [Makequestion, setMakeQuestion] = useState(false)
//     const [makeFieldtrue, setMakeFieldTrue] = useState(false)
//     const [openOption, setOpenOption] = useState(false)


//     const [makefalseaddQuestion, setMakeFalseAddQuestion] = useState(true)
//     // const [makeFalseFieldQuestion, setMakeFalseFieldQuestion] = useState(true)

//     const [MainOption, setMainOption] = useState(formData.Option)

//     const [normalquestion, setNormalQuestion] = useState(false)

//     const [MainQuestion, setMainQuestion] = useState(formData.Question)
//     const [fieldlabel, setFieldLabel] = useState('')

//     const [count, setCount] = useState(0)
//     countCopy = count;


//     const ADDQuestion = () => {
//         console.log('ADDQuestionBtn Clicked')
//         setMakeQuestion(true)
//         setMakeFalseAddQuestion(false)
//         setCount(count + 1)


//     }
//     //for field
//     const ADDField = () => {
//         console.log('AddField Clicked')
//         // setMakeQuestion(true)
//         setMakeFieldTrue(true)
//         setMakeFalseAddQuestion(false)
//         setCount(count + 1)

//     }



//     const SAVE = () => {
//         console.log('SAVE')
//         console.log(formData.Question)
//         setMainQuestion(formData.Question)
//         setOpenOption(true)
//         setCount(count + 1)

//     }

//     const SAVEField = () => {
//         console.log('SAVEField')
//         console.log(formData.TEXT)
//         // setMainQuestion(formData.label)
//         setFieldLabel(formData.TEXT)
//         setOpenOption(false)
//         setCount(count + 1)

//     }

//     const SAVE2 = () => {
//         console.log('SAVE')
//         console.log(formData.Option)
//         setMainOption(formData.Option)
//         setCount(count + 1)

//     }
//     const SAVE3 = () => {
//         console.log('SAVE')
//         console.log(formData.Question)
//         setNormalQuestion(formData.Question)
//         setOpenOption(true)
//         setCount(count + 1)


//     }

//     return (
//         <>
//             {/* <div className="firstBtn">
//                 <Button variant='contained' color='success'>
//                     Add Question

//                 </Button>        </div> */}
//             <div className='mainContainer'>


//                 {MainOption ? (
//                     <>
//                         <span style={{ fontSize: '25px', marginRight: '100px' }}>  {MainOption}</span>

//                         {makefalseaddQuestion && (
//                             <>
//                                 <Button variant='contained' color='secondary' style={{ marginRight: '20px' }} onClick={ADDQuestion}>AddQuestion</Button>
//                                 <Button variant='contained' color='success' onClick={ADDField}>AddField</Button>
//                             </>

//                         )}


//                         <br />
//                     </>

//                 ) :
//                     !isParent && (
//                         <>
//                             <input

//                                 label="Option"
//                                 required

//                                 // value={formData.name}
//                                 placeholder='Enter Option'
//                                 onChange={(e) => onChange('Option', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                             />
//                             <Button variant='contained' color='success' className='save' onClick={SAVE2}>Save</Button>

//                         </>

//                     )
//                 }

//                 {console.log(MainQuestion, 7777)}

//                 {MainQuestion ? (
//                     <>

//                         <h1 style={{ fontWeight: '500', fontSize: '30px' }}>Q:{MainQuestion}</h1>
//                         {/* <Button variant='contained' color='success' className='save' onClick={SAVE}>Save</Button> */}
//                     </>


//                 ) :
//                     isParent && (
//                         <><h1 style={{ display: 'inline' }}>Q:</h1>
//                             <input
//                                 label="Question"
//                                 required
//                                 value={formData.name}
//                                 onChange={(e) => onChange('Question', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                                 placeholder='Enter Main Question'
//                             />
//                             <Button variant='contained' color='success' className='save' onClick={SAVE}>Save</Button>

//                         </>

//                     )

//                 }

//                 {normalquestion ? (
//                     <span style={{ fontSize: '25px', marginRight: '100px' }}>{normalquestion}</span>

//                 ) :
//                     Makequestion &&
//                     (
//                         <>
//                             <input
//                                 label="Question"
//                                 required
//                                 value={formData.name}
//                                 onChange={(e) => onChange('Question', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                                 placeholder='Enter Question'
//                             />
//                             <Button variant='contained' color='success' className='save' onClick={SAVE3}>Save</Button>


//                         </>

//                     )

//                 }


//                 {fieldlabel ? (
//                     <span style={{ fontSize: '25px', marginRight: '100px' }}>{fieldlabel}</span>

//                 ) :
//                     makeFieldtrue && (
//                         <>
//                             <input
//                                 label="LABEL"
//                                 required
//                                 value={formData.name}
//                                 onChange={(e) => onChange('TEXT', e.target.value)}
//                                 variant="outlined"
//                                 fullWidth
//                                 margin="normal"
//                                 placeholder='Enter Field'
//                             />
//                             <Button variant='contained' color='success' onClick={SAVEField}>Save</Button>
//                         </>
//                     )
//                 }

//                 {formData.names &&
//                     formData.names.map((name, index) => (
//                         <SubForm
//                             key={index}
//                             formData={name}
//                             onChange={(field, value) => {
//                                 const newNames = [...formData.names];
//                                 newNames[index][field] = value;
//                                 onChange('names', newNames);
//                             }}
//                             onAddSubForm={onAddSubForm}
//                             onRemoveSubForm={() => {
//                                 const newNames = [...formData.names];
//                                 newNames.splice(index, 1);
//                                 onChange('names', newNames);
//                             }}
//                         />
//                     ))}
//                 {/* <Button onClick={()=>setAddtext(true)}>AddTEXT</Button> */}

//                 {openOption && (
//                     <Button variant="contained" color="primary" startIcon={<AddCircleIcon />} /* style={addButtonStyle}  */ onClick={handleAddSubForm}>
//                         {/* Add Sub-Form */}ADD OPTION
//                     </Button>
//                 )}

//                 {/* <Button className='mx-4' variant="contained" color="error" startIcon={<DeleteIcon />} onClick={onRemoveSubForm}>
//                 Remove Sub-Form
//             </Button> */}
//             </div>
//         </>

//     );
// };


// let aaa;
// let bbb;

// const ContactForm = () => {

//     let initForm = JSON.parse(localStorage.getItem('Forms')) || [{ Option: '', names: [], Question: '' }]

//     const [forms, setForms] = useState(initForm);

//     // aaa = {forms,setForms}
//     aaa = forms
//     bbb = setForms

//     const handleChange = (index, field, value) => {
//         setForms(prevForms => {
//             const newForms = [...prevForms];
//             newForms[index][field] = value;
//             return newForms;
//         });
//     };


//     const addSubForm = (formData) => {
//         if (!formData.names) {
//             formData.names = [];
//         }
//         formData.names.push({ Option: '', Question: '', names: [] });
//         setForms([...forms]);


//     };

//     const removeParentForm = (index) => {
//         const newForms = [...forms];
//         newForms.splice(index, 1);
//         setForms(newForms);
//     };

//     const handleSubmit = () => {
//         console.log('Form Data:', forms);
//         console.log('length:', forms.length);
//         // You can perform additional actions with the form data here.
//     };

//     useEffect(() => {
//         localStorage.setItem('Forms', JSON.stringify(forms))

//     }, [forms])

//     return (
//         <div>
//             <br />
//             <p style={{ fontSize: '30px' }}>Add work and sub work</p>
//             {forms.map((form, index) => (
//                 <div key={index}>

//                     <SubForm
//                         formData={form}
//                         onChange={(field, value) => handleChange(index, field, value)}
//                         onAddSubForm={() => addSubForm(form)}
//                         onRemoveSubForm={() => removeParentForm(index)}
//                         isParent={index === 0}
//                     />


//                     {index !== 0 && (
//                         <Button
//                             variant="contained"
//                             color="error"
//                             startIcon={<DeleteIcon />}
//                             onClick={() => removeParentForm(index)}
//                         >
//                             Remove Parent Form0
//                         </Button>
//                     )}
//                 </div>
//             ))}


//             {forms.length == 0 ? (
//                 <Button variant="contained" color="primary" onClick={() => setForms([...forms, { Option: '', Question: '', names: [] }])}>
//                     Add Parent Form
//                 </Button>
//             ) : ''}
//             <Button variant="contained" color="primary" onClick={handleSubmit}>
//                 Submit
//             </Button>
//             <Muitable countCopy={countCopy} />

//         </div>
//     );
// };


// export { aaa, bbb }
// export default ContactForm;







