import './App.css';

import React, { useEffect, useState } from 'react';
// import SubWork from './Component/Final/SubWork';

// import OwnFinal from './Component/Final/OwnFinal';  ---ended
// import MuiTable from './Component/Final/MuiTable';

// import Chat from './Component/Chat'
// import MyBuilder from './Component/MyBuilder';

// import LastPratise from './Component/LastPratise';  ---main component ----afterPractise


//below  important import 
// import DynamicForm from './Component/DynamicForm'
// import Chat from './Component/Chat'
// import ChatPractise from './Component/ChatPractise'
// import UserPractise from './Component/UserPractise'
import Maping from './Component/Maping'

// import FinalPart from './Component/Final/FinalPart'

// import CopyChat from './Component/Final/CopyChat'



function App() {


  return (
    <>

      {/* below  important import  */}
      {/* <DynamicForm /> */}
      <br />
      <br />
      <hr />

      {/* <UserPractise /> */}
      {/* <DynamicForm /> */}

      {/* <Chat /> */}


      {/* <hr />
      <hr />
      <hr /> */}
      {/* <ChatPractise /> */}


      {/* <FinalPart /> */}

      {/* <CopyChat /> */}

      {/* <LastPratise /> */}

      {/* <OwnFinal /> */}
      {/* <Chat /> */}
<Maping />

      {/* <MyBuilder /> */}


      {/* <SubWork /> */}

    </>

  );
}


export default App;

